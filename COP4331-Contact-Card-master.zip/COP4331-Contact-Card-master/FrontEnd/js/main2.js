var urlBase = 'https://group1homiescontactcard.online/LAMPAPI';
var extension = 'php';
/*eslint-env browser*/
var userId = 0;
var firstName = "";
var lastName = "";

$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});

function doLogin() {
    var login = document.getElementById("userLog").value;
    var password = document.getElementById("passLog").value;
    if (login === '') {
        document.getElementById("loginResult").innerHTML = "Please enter a Username";
        return;
    } else if (password === '') {
        document.getElementById("loginResult").innerHTML = "Please enter a Password";
        return;
    }
    var hash = md5(password);

    var jsonPayload = '{"login" : "' + login + '", "password" : "' + hash + '"}';
    var url = urlBase + '/login.' + extension;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try {
        xhr.send(jsonPayload);

        var jsonObject = JSON.parse(xhr.responseText);

        userId = jsonObject.id;

        if (userId < 1) {
            document.getElementById("loginResult").innerHTML = "    User/Password combination incorrect";
            return;
        }
        firstName = jsonObject.firstName;
        lastName = jsonObject.lastName;
        saveCookie();
        window.location.href = "home.html";
    } catch (err) {
        //document.getElementById("loginResult").innerHTML = err.message;
    }

}

function doCreateAccount() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var userName = document.getElementById("signUser").value;
    var password = document.getElementById("signPass").value;
    var password2 = document.getElementById("signPass2").value;

    // Verification off input
    if (firstName === '') {
        document.getElementsByName('username')[0].placeholder = 'Please enter your first name';
        return;
    } else if (lastName === '') {
        document.getElementsByName('username')[0].placeholder = 'Please enter your last name';
        return;
    } else if (userName === '') {
        document.getElementsByName('username')[0].placeholder = 'Please enter your user name';
        return;
    } else if (password === '') {
        document.getElementById("signUpResult").innerHTML = "Passwords do not match";
        return;
    } else if (password != password2) {
        document.getElementById("signUpResult").innerHTML = "Passwords do not match";
        return;
    }
    var hash = md5(password);

    // Preparing the JSON Package
    var jsonPayload = '{"firstName" : "' + firstName + '", "lastName" : "' + lastName + '","login" : "' + userName + '","password" : "' + hash + '"}';
    var url = urlBase + '/addUser.' + extension;
    // Sending JSON Package
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try {
        xhr.send(jsonPayload);
        var jsonObject = JSON.parse(xhr.response);
        console.log(jsonObject.Action);
        var answer = jsonObject.Action;
        // Failed to create an account
        if (answer != "Added") {
            document.getElementById("signUpResult").innerHTML = "Failure to create an account";
            return;
        } else {
            window.location.href = "index.html";
            //window.alert();
            return;
        }
    } catch (err) {
        document.getElementById("signUpResult").innerHTML = "Failure to create an account";
    }
}

function addContact() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var email = document.getElementById("email").value;
    var phoneNumber = document.getElementById("phoneNumber").value;
    // Verification of input
    if (firstName === '') {
        document.getElementById("addContactResponse").innerHTML = "First Name is required";
        document.getElementById("firstName").focus();
        return;
    } else if (lastName === '') {
        document.getElementById("addContactResponse").innerHTML = "Last Name is required";
        document.getElementById("lastName").focus();
        return;
    } else if (email === '' && phoneNumber === '') {
        document.getElementById("addContactResponse").innerHTML = "Either Email or Phone Number are required";
        document.getElementsByName("reset")[0].reset();
        return;
    }
    if (!(emailIsValid(email))) {
        document.getElementById("addContactResponse").innerHTML = "Not a valid Email";
        document.getElementById("email").focus();
        return;
    }
    phoneNumber = phoneFormat(phoneNumber);

    if (phoneNumber.length != 16) {
        document.getElementById("addContactResponse").innerHTML = "Not a valid Phone Number";
        document.getElementById("phoneNumber").focus();
        return;
    }
    document.getElementById("addContactResponse").innerHTML = "";
    // Preparing the JSON Package
    var jsonPayload = '{"firstName" : "' + firstName + '", "lastName" : "' + lastName + '","phoneNumber" : "' + phoneNumber + '","email" : "' + email + '","userID" : "' + userId + '"}';
    var url = urlBase + '/addContact.' + extension;
    // Sending JSON Package
    console.log(jsonPayload);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try {
        // myContacts[++contactSize] = jsonPayload; -DD
        xhr.send(jsonPayload);
        var jsonObject = JSON.parse(xhr.response);
        document.getElementById("addContactResponse").innerHTML = "Sucessfully Added Contact";
        document.getElementsByName("reset")[0].reset();
        //generateDynamicTable(myContacts); // or just update table -DD
    } catch (err) {
        document.getElementById("addContactResponse").innerHTML = err.message;
    }
}

function doSearch() {
    //$('#dataTable').remove();
    var firstName = document.getElementById("firstNameConfirm").value;
    var lastName = document.getElementById("lastNameConfirm").value;
    console.log(firstName + " " + lastName);
    //Verification of input
    if (firstName === '' && lastName === '') {
        document.getElementById("searchResponse").innerHTML = "You need atleast a first name or last name"
        document.getElementById("searchName").focus();
        return;
    }
    if (lastName === "undefined") {
        lastName = firstName;
    }
    if (firstName === "undefined") {
        firstName = lastName;
    }
    document.getElementById("searchResponse").innerHTML = "";
    // Preparing the JSON Package
    var jsonPayload = '{"firstName" : "' + firstName + '","lastName" : "' + lastName  + '","userID" : "' + userId + '"}';
    var url = urlBase + '/searchContact.' + extension;
    // Sending JSON Package
    console.log(jsonPayload);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try {
        xhr.send(jsonPayload);
        var jsonObject = JSON.parse(xhr.response);
        var answer = 0;
        if (1) {
            //alert(jsonObject[0].firstName);
            generateDynamicTable(jsonObject);
        }
    } catch (err) {
        document.getElementById("searchResponse").innerHTML = "No records found";
        return;
    }

}

function doDelete() {
    var firstName = document.getElementById("firstNameConfirm").value;
    var lastName = document.getElementById("lastNameConfirm").value;
     var ID = document.getElementById("idDelete").value;
    console.log(firstName + " " + lastName);
    // Verification of input
       if (firstName === "undefined" || lastName === "undefined" || ID === '')  {
        document.getElementById("searchResponse").innerHTML = "You need a first name, last name and ID"
        document.getElementById("searchName").focus();
        return;
    }
    confirm("Are you sure you want to delete " + firstName);
    // Preparing the JSON Package
    var jsonPayload = '{"firstName" : "' + firstName + '", "lastName" : "' + lastName +  '","ID" : "' + ID + '","userID" : "' +  userId + '"}';
    var url = urlBase + '/deleteContact.' + extension;
    // Sending JSON Package
    console.log(jsonPayload);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, false);
    xhr.setRequestHeader("Content-type", "application/json; charset=UTF-8");
    try {
        xhr.send(jsonPayload);
        var jsonObject = JSON.parse(xhr.response);
        var answer = jsonObject.Action;
        if (answer == 'Deleted') {
            document.getElementById("searchResponse").innerHTML = "Sucessfully Deleted";
            // generateDynamicTable(myContacts); // or just update table -DD
            doSearch();
        } else {
            document.getElementById("searchResponse").innerHTML = "YNo records found";
        }
    } catch (err) {
        document.getElementById("searchResponse").innerHTML = err.message;
    }
}

function saveCookie() {
    var minutes = 20;
    var date = new Date();
    date.setTime(date.getTime() + (minutes * 60 * 1000));
    document.cookie = "firstName=" + firstName + ",lastName=" + lastName + ",userId=" + userId + ";expires=" + date.toGMTString();
}

function generateDynamicTable(myContacts) {
    var noOfContacts = myContacts.length;
    var tableArray = new Array(),
        j = -1;
    for (var key = 0; key < noOfContacts; key++) {
        tableArray[++j] = '<tr><td>';
        tableArray[++j] = myContacts[key].firstName;
        tableArray[++j] = '</td><td class="whatever1">';
        tableArray[++j] = myContacts[key].lastName;
        tableArray[++j] = '</td><td class="whatever2">';
        tableArray[++j] = myContacts[key].email;
        tableArray[++j] = '</td><td class="whatever2">';
        tableArray[++j] = myContacts[key].phoneNumber;
        tableArray[++j] = '</td><td class="whatever2">';
        tableArray[++j] = myContacts[key].ID;
        tableArray[++j] = '</td></tr>';
    }
    $('#dataTable').html(tableArray.join(''));

}

function readCookie() {
    userId =  1;
    var data = document.cookie;
    var dataFormated = data.split(";").pop();
    var splits = dataFormated.split(",");
    for (var i = 0; i < splits.length; i++) {
        var thisOne = splits[i].trim();
        var tokens = thisOne.split("=");
        if (tokens[0] == "firstName") {
            firstName = tokens[1];
        } else if (tokens[0] == "lastName") {
            lastName = tokens[1];
        } else if (tokens[0] == "userId") {
            userId = parseInt(tokens[1].trim());
        }
    }
    if (userId < 0) {
        window.location.href = "index.html";
    } else {
        document.getElementById("Welcome").innerHTML = "Welcome " + firstName + " " + lastName;
    }
}

function doLogout() {
    console.log("We have logged out");
    userId = 0;
    firstName = "";
    lastName = "";
    document.cookie = "firstName= ; expires = Thu, 01 Jan 1970 00:00:00 GMT";
    window.location.href = "index.html";
}

// Splits Input string in Search Form into first name and last name
function autoPopulate() {
    var inputString = document.getElementById("searchName").value;
    var stringAfterSplit = inputString.split(" ");
    document.getElementById("firstNameConfirm").value = stringAfterSplit[0];
    document.getElementById("lastNameConfirm").value = stringAfterSplit[1];
}

function emailIsValid(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function phoneFormat(input) {
    // Strip all characters from the input except digits
    input = input.replace(/\D/g, '');

    // Trim the remaining input to ten characters, to preserve phone number format
    input = input.substring(0, 10);

    // Based upon the length of the string, we add formatting as necessary
    var size = input.length;
    if (size == 0) {
        //Empty for a reason
    } else if (size < 4) {
        input = '(' + input;
    } else if (size < 7) {
        input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6);
    } else {
        input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6) + ' - ' + input.substring(6, 10);
    }
    return input;
}