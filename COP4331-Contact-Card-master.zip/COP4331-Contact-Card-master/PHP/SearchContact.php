<?php

	$inData = getRequestInfo();
	
	$searchResults = array();
	$searchCount = 0;

	$conn = new mysqli("localhost", "xjuan244_Wildsoul", "LakeView1234!", "xjuan244_Contacts");
	if ($conn->connect_error) 
	{
		returnWithError( $conn->connect_error );
	} 
	else
	{
	    $firstName = $inData["firstName"];
	    $lastName = $inData["lastName"];
	    $userID = $inData["userID"];
	    
		$sql = "SELECT * FROM UserContacts WHERE userID = '$userID' AND (firstName LIKE '%$firstName%' OR lastName like '%$lastName%')";
		$result = $conn->query($sql);
		if ($result->num_rows > 0)
		{
			while($row = $result->fetch_assoc())
			{
				$searchResults[$searchCount] = array();
				$searchResults[$searchCount]['firstName'] = $row["firstName"];
			    $searchResults[$searchCount]['lastName'] = $row["lastName"];
			    $searchResults[$searchCount]['email'] = $row["email"];
			    $searchResults[$searchCount]['phoneNumber'] =$row["phoneNumber"];
			    $searchResults[$searchCount]['ID'] = $row["ID"];
				$searchCount++;
			}
		}
		else
		{
			returnWithError( "No Records Found" );
		}
		$conn->close();
	}
	//$results = print_r($searchResults, true);
	$json = json_encode($searchResults,JSON_PRETTY_PRINT);
	sendResultInfoAsJson($json);
	//returnWithInfo( $results );

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}
	
	function returnWithError( $err )
	{
		$retValue = '{"id":0,"firstName":"","lastName":"","error":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}
	
// 	function returnWithInfo( $searchResults )
// 	{
// 		$retValue = '{"results":"'. [$searchResults] . '","error":" 1 "}';
// 		sendResultInfoAsJson($retValue);
// 	}
	
?>
