<?php

	$inData = getRequestInfo();


    $firstName = $inData["firstName"];
    $lastName = $inData["lastName"];
	$userName = $inData["login"];
	$password = $inData["password"];

	$conn = new mysqli("localhost", "xjuan244_Wildsoul", "LakeView1234!", "xjuan244_Contacts");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{
	   
	    

		$sql = "INSERT INTO Users (firstName,lastName,login,password) VALUES ('$firstName','$lastName','$userName','$password')";

		if ( $result = $conn->query($sql) != TRUE )
		{
			returnWithError( $conn->error );
		}
			$conn->close();
		}

		returnWithInfo($userName,"Added");


	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"UserID":"' . $userID . '","firstName":"' . $firstName . '","lastName":"' . $lastName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}

	function returnWithInfo( $userName,$err )
	{
		$retValue = '{"UserName":"' . $userName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}

?>
