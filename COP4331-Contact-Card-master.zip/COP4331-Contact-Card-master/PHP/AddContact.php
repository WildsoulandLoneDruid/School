<?php
    
	$inData = getRequestInfo();
	
	$date = getdate();


  $firstName = $inData["firstName"];
  $lastName = $inData["lastName"];
  $phoneNumber = $inData["phoneNumber"];
  $email = $inData["email"];
  $dateString = $date[month] . "/" . $date[mday] . "/". $date[year];
  $userID = $inData["userID"];
  
	$conn = new mysqli("localhost", "xjuan244_Wildsoul", "LakeView1234!", "xjuan244_Contacts");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	
	else
	{

		$sql = "INSERT INTO UserContacts (firstName,lastName,phoneNumber,email,userID,date) VALUES ('$firstName','$lastName','$phoneNumber','$email','$userID','$dateString')";

		if ( $result = $conn->query($sql) != TRUE )
		{
			returnWithError( $conn->error );
		}
			$conn->close();
	}

		returnWithInfo($userID,$firstName,$lastName,"Added");


	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"UserID":"' . $userID . '","firstName":"' . $firstName . '","lastName":"' . $lastName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}
	
	function returnWithInfo( $userID, $firstName, $lastName,$err )
	{
		$retValue = '{"UserID":"' . $userID . '","firstName":"' . $firstName . '","lastName":"' . $lastName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}

?>
