<?php
    
	$inData = getRequestInfo();
	

  $firstName = $inData["firstName"];
  $lastName = $inData["lastName"];
  $userID = $inData["userID"];
  $ID = $inData["ID"];
  
	$conn = new mysqli("localhost", "xjuan244_Wildsoul", "LakeView1234!", "xjuan244_Contacts");
	if ($conn->connect_error)
	{
		returnWithError( $conn->connect_error );
	}
	else
	{

		$sql = "DELETE FROM UserContacts WHERE firstName = '$firstName' AND lastName = '$lastName' AND userID = '$userID' AND ID = '$ID'";

		if ( $result = $conn->query($sql) != TRUE )
		{
			returnWithError( $conn->error );
		}
		if ( $affectedRows = $conn -> affected_rows == 0)
		{
		    returnWithInfo($userID,$firstName,$lastName,"Not Deleted");
		} else {
		    returnWithInfo($userID,$firstName,$lastName,"Deleted");
		}
		 $conn->close();
	}

	function getRequestInfo()
	{
		return json_decode(file_get_contents('php://input'), true);
	}

	function sendResultInfoAsJson( $obj )
	{
		header('Content-type: application/json');
		echo $obj;
	}

	function returnWithError( $err )
	{
		$retValue = '{"id":"' . $userID . '","firstName":"' . $firstName . '","lastName":"' . $lastName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}

	function returnWithInfo( $userID, $firstName, $lastName,$err )
	{
		$retValue = '{"id":"' . $userID . '","firstName":"' . $firstName . '","lastName":"' . $lastName . '","Action":"' . $err . '"}';
		sendResultInfoAsJson( $retValue );
	}


?>
