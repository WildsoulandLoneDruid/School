// Sean Szumlanski
// COP 3502, Spring 2018
//
// n-squared-sorts.c
// =================
// Implementations of our O(n^2) sorting algorithms from class.


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void swap(int *array, int i, int j)
{
	int temp = array[i]; array[i] = array[j]; array[j] = temp;
}

void selection_sort(int *array, int n)
{
	int j, start, indexOfMin;

	for (start = 0; start < n; start++)
	{
		indexOfMin = start;

		for (j = start + 1; j < n; j++)
			if (array[j] < array[indexOfMin])
				indexOfMin = j;

		swap(array, start, indexOfMin);
	}
}

void insertion_sort(int *array, int n)
{
	int gap, peach, start;

	for (start = 1; start < n; start++)
	{
		peach = array[start];

		for (gap = start; gap > 0 && peach < array[gap-1]; gap--)
		{
			array[gap] = array[gap-1];
		}

		array[gap] = peach;
	}
}

// This is an alternate approach to insertion sort, which I did not discuss in
// lecture. Note that in this version, the swap function performs three
// assignment (=) operations per call, but my alternate version above only needs
// a single assignment operation where swap() used to be. Notice also the
// exclusion of the 'array[i] = peach' line, which is absolutely critical in the
// version above.
void alternate_insertion_sort(int *array, int n)
{
	int gap, peach, start;

	for (start = 1; start < n; start++)
	{
		peach = array[start];

		for (gap = start; gap > 0 && array[gap] < array[gap-1]; gap--)
		{
			swap(array, gap, gap - 1);
		}
	}
}

void bubble_sort(int *array, int n)
{
	int i, j = 0, temp, swapped = 1;

	while (swapped)
	{
		swapped = 0;

		for (i = 0; i < n - 1 - j; i++)
		{
			if (array[i] > array[i + 1])
			{
				swap(array, i, i + 1);
				swapped = 1;
			}
		}
		++j;
	}
}

void print_array(int *array, int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d%c", array[i], (i == n - 1) ? '\n' : ' ');
}

int is_sorted(int *array, int n)
{
	int i;

	for (i = 0; i < n - 1; i++)
		if (array[i] > array[i + 1])
			return 0;

	return 1;
}

int main(int argc, char **argv)
{
	int i, n, *array;
	srand(time(NULL));

	if (argc < 2)
	{
		fprintf(stderr, "Proper syntax: %s <n>\n", argv[0]);
		return 1;
	}

	n = atoi(argv[1]);
	array = malloc(sizeof(int) * n);

	for (i = 0; i < n; i++)
		array[i] = rand() % 100 + 1;

	printf("\nUnsorted array:\n");
	print_array(array, n);

	selection_sort(array, n);

	printf("\nSorted array:\n");
	print_array(array, n);

	printf("\n%s\n", is_sorted(array, n) ? "SORTED!" : "failwhale :(");

	// clean up after yourself
	free(array);

	return 0;
}
