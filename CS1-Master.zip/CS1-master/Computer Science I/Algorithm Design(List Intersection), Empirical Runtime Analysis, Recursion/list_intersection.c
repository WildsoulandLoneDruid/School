// Sean Szumlanski
// COP 3502, Spring 2018

// list_intersection.c
// ===================
// How can we find the elements that two sorted arrays have in common? This file
// contains the three approaches we saw in class, which were O(n^2), O(n log n),
// and O(n). The have been modified slightly to work with arrays that are not
// necessarily the same length. I've also included implementations of linear
// search and binary search, as well as some functions for generating arrays of
// random integers.


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_RAND_VAL 50

// Linear search. Returns 1 if the key is found in the array, 0 otherwise.
//
// Worst-case: O(n)  (linear time)
// Best-case:  O(1)  (constant time)
//
int linear_search(int *array, int n, int key)
{
	int i;
	
	for (i = 0; i < n; i++)
		if (array[i] == key)
			return 1;
	
	return 0;
}

// Binary search. Returns 1 if the key is found in the array, 0 otherwise.
//
// Worst-case: O(log n)
// Best-case:  O(1)
//
int binary_search(int *array, int n, int key)
{
	int lo = 0, hi = n - 1, mid;
	
	while (lo <= hi)
	{
		// Why use this instead of mid = (hi + lo) / 2, even though they're
		// algebraically equivalent?
		mid = lo + (hi  - lo) / 2;
		
		// If the key is less than the value at mid, consider only the left half
		// of the array.
		if (key < array[mid])
			hi = mid - 1;
		
		// If the key is greater than the value at mid, consider only the right
		// half of the array.
		else if (key > array[mid])
			lo = mid + 1;
		
		// Otherwise, we found the key! Hooray!
		else
			return 1;
	}

	return 0;
}

// This function is used by C's built-in qsort() function to sort the arrays.
int my_compare(const void *a, const void *b)
{
	return (*(int *)a - *(int *)b);
}

// Create and return a sorted array of n random integers.
int *create_sorted_array(int n)
{
	int i, *array = malloc(sizeof(int) * n);

	for (i = 0; i < n; i++)
		array[i] = rand() % MAX_RAND_VAL + 1;

	// Sort the arrays using C's QuickSort function. (See search.c for details.)
	qsort(array, n, sizeof(int), my_compare);

	return array;
}

// Print the contents of an integer array.
void print_array(int *array, int n)
{
	int i;

	if (n == 0)
	{
		printf("(empty)\n\n");
		return;
	}

	for (i = 0; i < n; i++)
		printf("%d ", array[i]);

	printf("\n\n");
}

// Print all the elements these two sorted arrays have in common. This function
// performs a linear search through array2 for each element of array1. This is
// O(len1 * len2). When len1 = len2 = n, this function is O(n^2).
void print_list_intersection(int *array1, int len1, int *array2, int len2)
{
	int i;

	for (i = 0; i < len1; i++)
		if (linear_search(array2, len2, array1[i]))
			printf("%d ", array1[i]);

	printf("\n\n");
}

// A cleverer approach: Do a binary search through array2 for each element of
// array1. This function is O(len1 * log(len2)). When len1 = len2 = n, this
// function is O(n log n).
void print_list_intersection_somewhat_fancier(int *array1, int len1, int *array2, int len2)
{
	int i;

	for (i = 0; i < len1; i++)
		if (binary_search(array2, len2, array1[i]))
			printf("%d ", array1[i]);

	printf("\n\n");
}

// This is the O(len1 + len2) approach described in class, which is O(n) when we
// have len1 = len2 = n.
void print_list_intersection_super_fancy(int *array1, int len1, int *array2, int len2)
{
	int i = 0, j = 0;
	
	while (i < len1 && j < len2)
	{
		if (array1[i] < array2[j])
		{
			++i;
		}
		else if (array1[i] > array2[j])
		{
			++j;
		}
		else
		{
			printf("%d ", array1[i]);
			i++;
			j++;
		}
	}

	printf("\n\n");
}

int main(void)
{
	int *array1, *array2, n, i;

	printf("How many integers shall we generate? ");
	scanf("%d", &n);

	srand(time(NULL));

	// Create and print two sorted arrays of random integers.
	array1 = create_sorted_array(n);
	array2 = create_sorted_array(n);

	printf("array1:\n");
	print_array(array1, n);

	printf("array2:\n");
	print_array(array2, n);

	// Call our various list intersection functions.
	printf("List Intersection:\n");
	print_list_intersection(array1, n, array2, n);

	printf("List Intersection:\n");
	print_list_intersection_somewhat_fancier(array1, n, array2, n);

	printf("List Intersection:\n");
	print_list_intersection_super_fancy(array1, n, array2, n);

	// Clean up after yourself.
	free(array1);
	free(array2);

	return 0;
}
