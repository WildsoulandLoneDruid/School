// Sean Szumlanski
// COP 3502, Spring 2018

// recursion-basics.c
// ==================
// These are some introductory recursive functions from class today. You should
// experiment with these functions. Make subtle changes to them. Inject printf()
// statements into them so you can trace through their execution. Become one
// with recursion.


#include <stdio.h>
#include <stdlib.h>

// A recursive function that sums all numbers from 0 to n.
// Assume n is a non-negative integer.
int sum(int n)
{
	// base case
	if (n == 0)
		return 0;

	// Note: We saw that there are sometimes other acceptable approaches to the
	// base case. For example, we could use either of the following here:
	//
	// Option 1:
	//
	// if (n == 0)
	//    return 0;
	// if (n == 1)
	//    return 1;
	//
	// Option 2 (which has the same result as option 1):
	//
	// if (n < 2)
	//    return n;

	return n + sum(n - 1);
}

/*
Here's what the return values are:

sum(n) = n + sum(n - 1)
             ^
             (n - 1) + sum(n - 2)
                       ^
                       (n - 2)  + sum(n - 3)
                                  ^
                                  ...and so on, until we call sum(0)

Here's a more concrete example:

sum(5) = 5 + (4 + 3 + 2 + 1 + 0)
             ^
           sum(4) = 4 + (3 + 2 + 1 + 0)
                        ^
                      sum(3) = 3 + (2 + 1 + 0)
                                   ^
                                 sum(2) = 2 + (1 + 0)
                                              ^
                                            sum(1) = 1 + (0)
                                                         ^
                                                       sum(0) = 0 (base case!)
*/

// A basic min() function, called by find_min().
int min(int a, int b)
{
	// The conditional operator is fancy!
	return (a < b) ? a : b;
}

// Recursively find the minimum element in an array. n is the length of the
// array, which you may assume is at least 1.
int find_min(int *array, int n)
{
	// If there's just one element in the array, boom -- that's the min!
	if (n == 1)
		return array[0];

	// Otherwise, the minimum element is the minimum of the following two
	// values:
	//  -> the last element in the array (i.e., array[n-1])
	//  -> the minimum element out of the first (n-1) elements in the array
	//     (i.e., find_min(array, n-1))
	return min(array[n-1], find_min(array, n-1));
}

int main(void)
{
	int *ptr = NULL;

	// You all generated this array of "random" integers in class.
	int array[] = {13, 27, 78, 42, 69, 2, 5, 21, 5, 5, 47, 1729, 14};

	// You can verify the results here are correct for different values of 'n'
	// using the summation formula we derived in class.
	printf("sum(5) = %d\n\n", sum(5));

	printf("Min element in array: %d\n\n", find_min(array, 13));

	// Kind of random, but here's another example of the conditional operator
	// in action:
	printf("ptr is %s\n", (ptr == NULL) ? "NULL" : "non-NULL");

	return 0;	
}
