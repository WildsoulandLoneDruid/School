// Sean Szumlanski
// COP 3502, Spring 2018


#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                       '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

// A function to convert from base 10 to an arbitrary base. This version handles
// conversions up to (and including) base 16.
//
// Suggested Exercise: Implement this function iteratively using a stack. Do it
//                     with linked lists. :)
//
void fromBase10Helper(int n, int base)
{
	if (n == 0)
		return;
	
	fromBase10Helper(n / base, base);
	printf("%c", digits[n % base]);
}

void fromBase10(int n, int base)
{
	if (n == 0)
		printf("0");
	else
		fromBase10Helper(n, base);

	printf("\n");
}

void panic(char *err_msg)
{
	fprintf(stderr, "%s\n", err_msg);
	exit(1);
}

int toDigit(char c)
{
	char err_msg[100];
	c = tolower(c);

	if (c >= '0' && c <= '9')
	{
		return c - '0';
	}
	else if (c >= 'a' && c <= 'z')
	{
		return c - 'a' + 10;
	}
	else
	{
		sprintf(err_msg, "Fatality in toDigit(): Could not convert '%c' to int!", c);
		panic(err_msg);
	}
}

// An efficient function to convert a string of characters to base 10. It avoids
// repeatedly calling the pow() function. So awesome!
int toBase10(char *str, int base)
{
	int i, length = strlen(str), result = 0;
	
	for (i = 0; i < length; i++)
	{
		// This is Horner's rule. Recall that we did something similar for a
		// string hashing function when we talked about hash tables.
		//
		// Alternatively, we could just compute different powers of the base
		// directly, like so:
		//
		//    result += (str[i] - '0') * pow(fromBase, length - i - 1);
		//
		result *= base;
		result += toDigit(str[i]);
	}

	return result;
}

// Example program calls:
//
//   ./a.out a2d 16 10
//   ./a.out 2605 10 16
//   ./a.out 1101011 2 4
//
int main(int argc, char **argv)
{
	int fromBase, toBase, n;

	if (argc < 4)
	{
		fprintf(stderr, "Proper syntax: %s <n> <fromBase> <toBase>\n", argv[0]);
		return 0;
	}

	fromBase = atoi(argv[2]);
	toBase = atoi(argv[3]);

	if (fromBase == 10)
	{
		// This function prints the result.
		fromBase10(atoi(argv[1]), toBase);
	}
	else if (toBase == 10)
	{
		// The toBase10() function doesn't print the result; it just returns it.
		n = toBase10(argv[1], fromBase);
		printf("%d\n", n);
	}
	else
	{
		// If neither the fromBase nor the toBase are 10, we can use 10 as
		// an intermediary base as we perform the conversion. It's nice that
		// the toBase10() function doesn't print the result, because this way
		// our program doesn't print that intermediary value.
		n = toBase10(argv[1], fromBase);
		fromBase10(n, toBase);
	}
	return 0;
}
