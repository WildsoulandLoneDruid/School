// Sean Szumlanski
// COP 3502, Spring 2018

// swappy-swap.c
// =============
// Two versions of a swap() function: a busted pass-by-value version, and a
// fully functional pass-by-reference version.


#include <stdio.h>

// This is a pass-by-value function, and it doesn't actually work. When it
// returns to main(), we find that the values of i and j haven't been swapped at
// all. (Why?)
void old_swap(int i, int j)
{
	int temp = i;
	i = j;
	j = temp;
}

// This is a pass-by-reference function, and it works correctly. When it returns
// to main(), we see that the values of i and j have actually been swapped this
// time.
void swap(int *i, int *j)
{
	int temp = *i;
	*i = *j;
	*j = temp;
}

int main(void)
{
	int i = 20, j = 57;

	swap(&i, &j);

	printf("i = %d, j = %d\n", i, j);

	return 0;
}
