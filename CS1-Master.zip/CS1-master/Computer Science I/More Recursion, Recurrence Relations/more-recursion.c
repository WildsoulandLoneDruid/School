// Sean Szumlanski
// COP 3502, Spring 2018

// more-recursion.c
// ================
// More recursion from today's class. Includes runtime analysis and the fast
// exponentiation function, which we will cover in our next lecture. For your
// benefit, this file includes additional examples not covered in class.


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// First, we saw how to write a basic min() function with the conditional
// operator.
int min(int a, int b)
{
	// The conditional operator is fancy!
	return (a < b) ? a : b;
}

// Write a RECURSIVE function that finds the minimum element in an array of
// n integers. You may assume the array is non-empty (i.e., n >= 1).
int find_min(int *array, int n)
{
	// If there's just one element in the array, boom -- that's the min!
	if (n == 1)
		return array[0];

	// Otherwise, the minimum element is the minimum of the following two
	// values:
	//  -> the last element in the array (i.e., array[n-1])
	//  -> the minimum element out of the first (n-1) elements in the array
	//     (i.e., find_min(array, n-1))
	return min(array[n-1], find_min(array, n-1));
}

// NOTE: The runtime for the above function can be represented using the
//       following recurrence relation:
//
// T(1) = c_1
// T(n) = c_2 + T(n-1) for n > 1


// This version peels off the front of the array instead of the back of the
// array. It uses pointer arithmetic to do so.
int find_min_fancy(int *array, int n)
{
	// If there's just one element in the array, boom -- that's the min!
	if (n == 1)
		return array[0];

	// NOTE: Alternatively, we could use &(array[1]) in place of array+1 below.
	return min(array[0], find_min_fancy(array+1, n-1));
}


// An alternate version of find_min(), which is just bananas. This is fairly
// unreadable and unnecessary, but I want you to see how powerful the
// conditional operator is. It allows us to write a recursive find_min()
// function in just one line of code! (This was not shown in the 12:30 class.)
int crazy_find_min(int *array, int n)
{
	return (n == 1) ? array[0] : min(array[n-1], crazy_find_min(array, n-1));
}


// Write a RECURSIVE function that returns n!, where n is a non-negative
// integer. Recall that n! = 1 * 2 * ... * (n-1) * n, and 0! = 1.
int factorial(unsigned int n)
{
	if (n == 0)
		return 1;

	// The idea here is, n! = n * (n - 1)!. We have a recursive function call
	// that can calculate (n - 1!), so we're good to go!
	return n * factorial(n - 1);
}

// BONUS FUNCTION! (This was not covered in class.)
//
// A recursive function to multiply integers a and b using only addition and
// subtraction operators. Assume a and b are non-negative integers.
//
// Recall that this is an iterative solution:
//
//    for (sum = i = 0; i < a; i++)
//       sum += b;
int mult(int a, int b)
{
	int x;
	
	if (a == 0 || b == 0)
		return 0;
	
	return a + mult(a, b - 1);
}

// A recursive function to print a string character-by-character. Uses pointer
// arithmetic. Is moderately fancy.
void print_string(char *str, int n)
{
	// I'm checking for NULL just in case the person calling this function is a
	// total jerk.
	if (n == 0 || str == NULL)
	{
		printf("\n");
		return;
	}

	// Print the first character.
	printf("%c", str[0]);

	// Recall that 'str' is the base address of the array, and (str+1) is the
	// address of the second element in the array. By moving the address forward
	// with each recursive call, we're essentially restricting each recursive
	// call's view of the array to a smaller and smaller slice, until we aren't
	// passing it a valid address at all.

	// Recursively print the remaining characters.
	print_string(str + 1, n - 1);
}

// Another approach to print_string(). This one prints the last character of the
// string after recursively printing the first (n-1) characters. This one
// assumes n >= 1.
void print_string_alternate(char *str, int n)
{
	if (n == 1)
	{
		printf("%c", str[0]);
		return;
	}

	// Recursively print the remaining characters.
	print_string_alternate(str, n - 1);

	// Print the last character.
	printf("%c", str[n-1]);
}

// Another recursive approach. This one just goes until it sees a null
// sentinel ('\0'). (This was not written in class. It's just an extra example
// for you to consider.)
void print_string_fancy(char *str)
{
	// Note: The (*str == '\0') condition is the same as using (str[0] == '\0').
	if (str == NULL || *str == '\0')
	{
		printf("\n");
		return;
	}

	printf("%c", *str);
	print_string_fancy(str + 1);
}

// A recursive function to print a string character-by-character in reverse order.
// Uses pointer arithmetic.
void print_string_reverse(char *str, int n)
{
	if (n == 0 || str == NULL)
	{
		printf("\n");
		return;
	}

	// Print the last character.
	printf("%c", str[n-1]);

	// Recursively print the remaining characters.
	print_string_reverse(str, n - 1);
}

// A recursive function to print a string character-by-character in reverse order.
// It's a twist on the original print_string() function, except it prints
// characters *after* returning from recursive calls! (This was not covered in
// class. I'm including it just so you can see more examples of what you can do
// with recursion.)
void print_string_reverse_fancy(char *str, int n, int original_length)
{
	if (n == 0 || str == NULL)
		return;

	// Recursively print the remaining characters.
	print_string_reverse_fancy(str + 1, n - 1, original_length);

	// Print the last character.
	printf("%c", str[0]);

	// If we've returned to our original call, go ahead and print the \n.
	if (n == original_length)
		printf("\n");
}

// Write a recursive function that takes two non-negative integers, a and n,
// and returns a^n (a to the power of n).
unsigned int power(unsigned int a, unsigned int n)
{
	if (n == 0)
		return 1;

	if (a == 0)
		return 0;

	return a * power(a, n - 1);
}

// We saw the following runtime analysis for the power() function:
//
// T(0) = c_2
// T(n) = c_1 + T(n - 1) for n > 0
//
// Recall that T(n) is "the runtime of the function with input n."
// Recall also that T(0) = c_2 is the "initial condition."
//
// Using that formula, we can also plug (n - 1) in for (n) and get:
//
// T(n - 1) = c_1 + T((n - 1) - 1)
//          = c_1 + T(n - 2)
//
// Now, let's substitute into the original formula until we start to see a
// pattern emerge:
//
// T(n) = c_1 + T(n - 1)
//      = c_1 + c_1 + T(n - 2)                = 2 * c_1 + T(n - 2)
//      = c_1 + c_1 + c_1 + T(n - 3)          = 3 * c_1 + T(n - 3)
//      = c_1 + c_1 + c_1 + c_1 + T(n - 4)    = 4 * c_1 + T(n - 4)
//      = ...
//      = k * c_1 + T(n - k)                  <-- generalized form
//
// (That process was called "iterative substitution.")
//
// Notice that this T(n-k) term is approaching our terminating condition, which
// is T(0) = c_2. So, we want to know what this generalized form looks like when
// we hit that terminating condition. In other words, we want to see what happens
// when (n - k) = 0? Notice that if (n - k) = 0, that means n = k. Thus, we get:
//
// T(n) = k * c_1 + T(0)         -- substituting (n - k) = 0
//      = n * c_1 + T(0)         -- substituting n = k
//      = n * c_1 + c_2          -- substituting T(0) = c_2 (given)
//
//  => T(n) is O(n)              -- dropping constants and lower-order terms
//             ^ TADA!



// A faster approach to the recursive power function.
//
// Note: If n is even, a^n = a^(n/2) * a^(n/2).
//       If n is odd, a^n = a * a^(n/2) * a^(n/2). <- Using integer division
//
// Runtime: O(log n) (see analysis below)
unsigned int super_fancy_recursive_power(unsigned int a, unsigned int n)
{
	int result;

	if (n == 0)
		return 1;

	if (a == 0)
		return 0;

	result = super_fancy_recursive_power(a, n/2);
	return result * result * ((n % 2 == 0) ? 1 : a);
}

// This is the runtime analysis for super_fancy_recursive_power():
//
// T(0) =~ T(1) = c_2
// T(n) = c_1 + T(n/2) for n > 1
//
// Using iterative substitution, we find:
//
// T(n) = c_1 + T(n/2)
//      = c_1 + (c_1 + T(n/4))                   = 2 * c_1 + T(n/4)
//      = c_1 + (c_1 + (c_1 + T(n/8)))           = 3 * c_1 + T(n/8)
//      = c_1 + (c_1 + (c_1 + (c_1 + T(n/16))))  = 4 * c_1 + T(n/16)
//      = ...
//      = k * c_1 + T(n/(2^k))
//
// We know the runtime for T(1), so let's let (n/(2^k)) = 1 so we can plug that
// in. Solving for k, we get:
//
//     n/(2^k) = 1
//  => n = 2^k                -- multiplying both sides by 2^k
//  => log_2(n) = log_2(2^k)  -- taking log_2 of both sides
//  => log_2(n) = k           -- since log_2(2^k) = k
//
// Then, plugging into that general form, we get:
//
// T(n) = log_2(n) * c_1 + T(1) = log_2(n) * c_1 + c_2 = O(log n)


int main(int argc, char **argv)
{
	int a = 2, b = 5;

	printf("%d! = %d\n", b, factorial(b));
	printf("%d * %d = %d\n", a, b, mult(a, b));
	printf("%d ^ %d = %d\n", a, b, power(a, b));
	printf("%d ^ %d = %d\n", a, b, super_fancy_recursive_power(a, b));

	print_string("sandwiches", strlen("sandwiches"));
	print_string_fancy("sandwiches");
	print_string_reverse("sandwiches", strlen("sandwiches"));

	return 0;
}
