// Sean Szumlanski
// COP 3502, Spring 2018

// more-linked-lists.c
// ===================
// Additional linked list functions from class.


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Traditional linked list node.
typedef struct node
{
	int data;
	struct node *next;
} node;

// Create a new node. Properly initialize all fields.
node *create_node(int data)
{
	node *new_node = malloc(sizeof(node));

	new_node->data = data;
	new_node->next = NULL;

	return new_node;
}

// Iteratively free all memory associated with this linked list. Returns NULL
// so I can easily set the head pointer in main() back to NULL by calling the
// function like so:
//
//    head = destroy_linked_list(head);
//
node *destroy_linked_list(node *head)
{
	node *current = head;
	node *temp;

	while (current != NULL)
	{
		temp = current->next;
		free(current);
		current = temp;
	}

	return NULL;
}


// Recursively free all memory associated with this linked list.
node *recursive_destroy_linked_list(node *head)
{
	if (head == NULL)
		return NULL;

	// We destroy the *rest* of the linked list, then come back to this node
	// and destroy it. So, we destroy the tail of the list first, then work
	// our way back toward the head.
	recursive_destroy_linked_list(head->next);

	// Try uncommenting this printf() line and tracing through what the code is
	// doing.
	//printf("Destroying the node with %d...\n", head->data);
	free(head);

	return NULL;
}

// Another approach to destroying the linked list recursively.
node *alternative_recursive_destroy_linked_list(node *head)
{
	node *temp;

	if (head == NULL)
		return NULL;

	temp = head->next;
	free(head);

	return alternative_recursive_destroy_linked_list(temp);
}

// Recursive tail insertion function. Returns the head of the list. This is
// an O(n) approach.
node *recursive_tail_insert(node *head, int data)
{
	if (head == NULL)
		return create_node(data);

	// Indeed, if we want to insert at the tail of this list, that's the same
	// as wanting to insert at the tail of the list headed up by head->next.
	head->next = recursive_tail_insert(head->next, data);
	return head;
}

// New, faster implementation of tail_insert(), which takes the tail pointer and
// inserts a new node in O(1) time. Returns a pointer to the new tail of the
// list.
node *fast_tail_insert(node *tail, int data)
{
	if (tail == NULL)
		return create_node(data);

	tail->next = create_node(data);
	return tail->next;
}

// Our old version of tail_insert(), which was O(n). Returns a pointer to the
// head of the list.
node *tail_insert(node *head, int data)
{
	node *temp = head;

	if (head == NULL)
		return create_node(data);

	while (temp->next != NULL)
		temp = temp->next;

	// By the time we reach this line, 'temp' is pointing to the last node in
	// the linked list (i.e., the tail of the list).
	temp->next = create_node(data);
	return head;
}

// Iterative print_list() function.
void print_list(node *head)
{
	// Note that we don't need a temp variable. We can change 'head' without
	// messing up the linked list, because it's a local variable. This does
	// not change the value of 'head' back in main().

	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	while (head != NULL)
	{
		printf("%d%c", head->data, (head->next == NULL) ? '\n' : ' ');
		head = head->next;
	}
}

// A recursive version of the print_list() function.
void recursive_print_list_helper(node *head)
{
	if (head == NULL)
		return;

	printf("%d%c", head->data, (head->next == NULL) ? '\n' : ' ');
	recursive_print_list_helper(head->next);
}

// A gateway function that only lets us call the recursive version if the list
// is non-empty. This way, we can print "(empty list)" if the list is empty,
// and not worry about that being printed in the base case after we've printed
// an entire list with the actual recursive function.
void recursive_print_list(node *head)
{
	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	recursive_print_list_helper(head);
}

// A recursive function that prints the list in reverse order. Notice that we
// just changed the order of the recursive call and the print statement.
void reverse_print_list_helper(node *head)
{
	if (head == NULL)
		return;

	reverse_print_list_helper(head->next);
	printf("%d ", head->data);
}

// Gateway function for the recursive function that prints the list in reverse
// order.
void reverse_print_list(node *head)
{
	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	reverse_print_list_helper(head);
	printf("\n");
}

// Head insertion function. This is an O(1) function. This function should be
// called like so:
//
//    head = head_insert(head, data);
//
// Notice that this function works even if head is NULL. :)
node *head_insert(node *head, int data)
{
	node *new_head = create_node(data);
	new_head->next = head;
	return new_head;
}

int main(int argc, char **argv)
{
	node *head = NULL, *tail = NULL;
	int i, r, n = 5;

	srand(time(NULL));

	for (i = 0; i < n; i++)
	{
		printf("Inserting %d...\n", r = rand() % 100 + 1);
		tail = tail_insert(tail, r);

		// If the list was empty, we also need to update the head pointer. (The
		// single node in the linked list is both the head and the tail.)
		if (head == NULL)
			head = tail;
	}

	printf("\nprint_list(head):\n");
	print_list(head);

	printf("\nrecursive_print_list(head):\n");
	recursive_print_list(head);

	printf("\nreverse_print_list(head):\n");
	reverse_print_list(head);

	// Clean up after yourself.
	head = alternative_recursive_destroy_linked_list(head);

	return 0;
}
