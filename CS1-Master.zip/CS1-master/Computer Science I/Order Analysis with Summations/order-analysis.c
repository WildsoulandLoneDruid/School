// Sean Szumlanski
// COP 3502, Spring 2018

// order-analysis.c
// ================
// Here are several of the functions I presented in class today for order
// analysis. Recall that we find big-oh by dropping constants and looking for
// the highest-order term.


// BONUS KNOWLEDGE:
// ================
// This program will not compile into an executable because it does not include
// a main() function. However, you can compile it into an object file at the
// command line using the following (which won't link it into an executable
// file, but will at least verify that this can be compiled without errors):
//
//   gcc -c order-analysis.c


#include <stdio.h>
#include <string.h>
#include <ctype.h>    // why is this included?


// PART 1: An INCORRECT approach to examining runtimes.
// ====================================================
// In discussing runtimes for segments of code (or entire functions), we first
// saw that comparing actual runtimes is a bad idea for a number of reasons.
// Instead, we developed a framework for theoretical runtime analysis.

// In terms of theoretical runtime analysis, we started with this approach,
// which is on the right track, but has some key problems: In this approach,
// we are interested in counting the number of steps or instructions executed.
// For foo(), let's count:
//
// 1. Assignment statements
// 2. Comparisons
// 3. Arithmetic operations

int foo(int *array, int n)
{
	int i, sum = 0;

	for (i = 0; i < n; i++)
		sum += array[i];

	return sum;
}

// sum = 0   --- executed once.
// i = 0     --- executed once.
// i < n     --- executed (n + 1) times (Do you see why it's (n + 1) and not n?)
// i++       --- executed n times
// sum +=... --- executed n times
//
// Note: We could consider sum += array[i] two operations if we wanted to, but
// we'll see shortly that this doesn't really matter for the kind of analysis
// we'll be doing.)

// Total: T(n) = 3n + 3
//
//        ^ Notice that this runtime is written as a function, T, of some input
//          variable, n. This is the variable (or, in some cases, just one of
//          multiple variables) that affects the runtime. It other cases, it
//          might be the length of an array, an integer we want to manipulate,
//          the number of elements in a linked list, etc.
//
// Here are some problems with our runtime:
//
// 1.) It's very easy to mis-count our terms! Should the += operation count as
//     one or two? Are there other places where we need to worry about this?
//     What exactly counts as an instruction? Should we include declarations in
//     our count? What about the cost of accessing array[i] so that we can add
//     it to our sum? There are simply too many possibilities for us to consider
//     all of them with great precision.
//
// 2.) Differences in constants can be misleading because different
//     architectures reduce these to different numbers of low-level processor
//     instructions.
//
//     E.g., T1(n) = 3n^2 + 5, T2(n) = 6n^2 + 5
//
//                                     ^ What if these particular instructions
//                                       are actually *faster* to execute on
//                                       my processor than the ones in T1? I.e.,
//                                       they only take two cycles instead of
//                                       three?
//
// 3.) It's rather pointless to focus on lower-order terms, isn't it? As n
//     approaches any sort of meaningful (i.e., LARGE) input size, the lower-
//     order terms become irrelevant.


// Part 2: Order Analysis (Big-Oh)
// ===============================
// Let's discuss...
//
//         O R D E R   A N A L Y S I S
//              (" B I G - O H ")
//
//                           ^ Hey, this is a big deal!
//
//
//  1. Assume your input (such as n) is HUGE.
//
//  2. Identify the statement(s) that are executed the most
//     and count how many times they occur. That's your
//     runtime
//
//  3. Find the highest-order term and drop any constants.
//
//       ^
//      That's your big-oh runtime.


// Big-Oh frees us from the problems listed above. We saw that we drop
// coefficients and focus on the highest-order term in each runtime.

// Here are some examples:

// For foo(), T(n) = 3n + 3, which is O(n)

// T1(n) = n + 3(n^3) + 2(n^2) + 1055     =>  O(???)   (fill in the blank)
// T2(n) = (1/6)(n^3) + 1000(n^2)         =>  O(???)
// T3(n) = n log n + log n + n            =>  O(???)
// T4(n) = sqrt(n) + 4n + 16(log n) + 23  =>  O(???)
// T5(n) = 50                             =>  O(1)

// Note:
// When a runtime is constant, we drop that coefficient and just write that
// the big-oh runtime is O(1). For example, the following function has
// constant runtime (it does not change even if the array is very large),
// so we would write that its runtime is O(1) (not O(50)):
//
int foo0(int *array, int n)
{
	int i;
	for (i = 0; i < 50; i++)
		printf("Hooray!\n");
	return n;
}



// Ignoring the constants involved with (i <= 100 * n) comparisons and (i++)
// incrementing, and focusing instead on the number of times (x++) is
// executed, we have the following runtime for foo1():
//
//   T(n) =~ 101n, which is O(n)
//
// We say foo1() is "order n," or "big-oh n." Sometimes I write T(n) = 101n = O(n),
// which isn't to say that 101n is *mathematically equal to* O(n), but rather, I'm
// just using the second equal sign as shorthand for the word "is".

int foo1(int n)
{
	int i, x = 0;

	for (i = 0; i <= 100 * n; i++)
		x++;

	return x;
}



// Modifying foo1() slightly can give us a drastically different *actual*
// runtime, but the order is still the same. The moral of the story is, Big-Oh
// can be a bit misleading:
//
//   T(n) = 2n, which is O(n) (even though this is 50x faster than foo1()!)

int foo1a(int n)
{
	int i, x = 0;

	for (i = 1; i <= n; i++)
		x++;
	for (i = 1; i <= n; i++)
		x++;
	return x;
}



// What happens if we replace the 100 in foo1() with another n?
//
// This function is now O(n^2).

int foo1b(int n)
{
	int i, x = 0;

	for (i = 0; i <= n * n; i++)
		x++;

	return x;
}



// This one is O(n^2).

int foo2(int n)
{
	int i, j, x = 0;

	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++)
			// How many times does this line get executed?
			x++;

	return x;
}



// What if we change the inner loop of foo2() to go from j = 1 to 10? Then our
// runtime is approximately:
//
//   T(n) = 10n, which is O(n)

int foo2a(int n)
{
	int i, j, x = 0;
	
	for (i = 1; i <= n; i++)
		for (j = 1; j <= 10; j++)
			// How many times does this line get executed?
			x++;
	
	return x;
}



// NOTE: We will cover this in class next time. This one involves some really
//       funky analysis. It turns out the runtime is logarithmic.

int foo3(int n)
{
	int i = n, x = 0;

	while (i > 0)
	{
		i = i / 2;
		x++;
	}
	return n;
}



// This is O(n log n). The O(log n) function foo3() is called n times.

int foo4(int n)
{
	int i, sum = 0;
	
	for (i = 0; i < n; i++)
		sum += foo3(n);
	
	return sum;
}



// This is O(log n). The O(log n) function foo3() is called 100 times, and we
// drop the constant to get Big-Oh: T(n) =~ 100*log n, which is O(log n).
// Again, for T(n), I am only counting how many times the sum+= line is
// executed.

int foo4a(int n)
{
	int i, sum = 0;
	
	for (i = 0; i < 100; i++)
		sum += foo3(n);
	
	return sum;
}



// Here, assume that foo3(n) is O(log n) *AND* it returns n. In that case, this
// function is still O(n log n). The O(log n) function foo3(n) is called (n + 1)
// times -- once for each of the (i < n) comparisons!

int foo4b(int n)
{
	int i, sum = 0;
	
	for (i = 0; i < foo3(n); i++)
		sum += 2;
	
	return sum;
}



// This one is O(b). Recall that we cannot write O(n) here, since n does not
// appear anywhere in the function. (Alternatively, we could define n in our
// statement about the runtime. We could write, "This function is O(n), where
// n = b." But that's just silly.)

int mult(int a, int b)
{
	int i, prod = 0;

	for (i = 0; i < b; i++)
		prod += a;

	return prod;
}



// This slight modification makes the runtime O(MIN{a,b}), which can make a HUGE
// difference. (Suppose, e.g., a = 1,000,000,000 and b = 2. This new approach
// results in immense savings!)

int faster_mult(int a, int b)
{
	int i, temp, prod = 0;

	// Swappy-swap. This ensures the smaller value of a and b will govern the
	// runtime of the for-loop.
	if (a < b)
	{
		temp = a; a = b; b = temp;
	}
	
	for (i = 0; i < b; i++)
		prod += a;
	
	return prod;
}



// We saw that the runtime of this algorithm can be expressed as O(MAX{a, b}).
// This is equivalent to O(a + b). (Do you remember why?)

int troll_mult(int a, int b)
{
	int i, temp, prod = 0;

	// This ensures the larger value of a and b will govern the runtime of
	// the for-loop. lul
	if (a > b)
	{
		temp = a; a = b; b = temp;
	}
	
	for (i = 0; i < b; i++)
		prod += a;
	
	return prod;
}



// In this one, assuming n is the length of str, then strlen(str) is being
// called n times -- once for each time through the for-loop. Since strlen(str)
// is an O(n) function (it loops through all n characters in our string, this
// print_upper() function ended up being O(n^2).

void print_upper(char *str)
{
	int i;
	
	for (i = 0; i < strlen(str); i++)
		printf("%c", toupper(str[i]));

	printf("\n");
}


// This minor modification to print_upper() transforms the order of the function
// from O(n^2) into O(n). We still have two O(n) chunks of code: len = strlen(str)
// is O(n), and the for-loop here is O(n), but their results are additive, not
// multiplicative, since strlen(str) is no longer nested *within* the for-loop
// construct.
//
// Incidentally, we would need to include string.h for strlen() and ctype.h for
// toupper().

void faster_print_upper(char *str)
{
	int i, len = strlen(str);
	
	for (i = 0; i < len; i++)
		printf("%c", toupper(str[i]));
	
	printf("\n");
}



// This does one step of work no matter what. It's O(1), or "constant order."
// Note that we never write O(13) or O(5003). If it's a constant runtime, write
// O(1).
int foo13(void)
{
	return 13;
}



// This is still O(1), because we return in the very first iteration of the
// for-loop!

int foo13a(int n)
{
	int i;

	for (i = 0; i < n; i++)
		return 13;
}



// This is still O(1), because the for-loop has a constant runtime.

int foo13b(void)
{
	int i, x = 0;

	for (i = 0; i < 500; i++)
		x++;

	return 13;
}
