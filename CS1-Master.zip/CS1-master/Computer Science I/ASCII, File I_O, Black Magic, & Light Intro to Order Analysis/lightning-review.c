// Sean Szumlanski
// COP 3502, Spring 2018
//
// Lightning Review from class today.


// ===============================
// 1. Fix the errors in this code:
// ===============================

   #include <stdio.h>

   struct T
   {
      int gl;
      char name[5];
   }
   // One problem is that we don't have a semicolon at the end of the struct
   // definition (after the closing curly brace).

   int main(void)
   {
      // T isn't a valid datatype. It's "struct T", unless I use a typedef to
      // make T and alias for struct T.
      T data;

      data.gl = 597;
      data->name = "Vince";
      // ^ Everything is wrong with this line. It should be a dot (.) operator,
      // not an arrow (->) operator, because 'data' isn't a pointer. Also, we
      // should use strcpy(data.name, "Vince") in order to copy that name over
      // correctly. And finally, "Vince" is too long to copy into the 'name'
      // array, because there's no room for the null sentinel ('\0'). That null
      // sentinel is being written out of bounds of the 'name' array, corrupting
      // who-knows-what in memory.

      printf("%s (%d)\n", data->name, data.gl);
      // ^ Again, this line should use data.name, not data->name.

      // Note: If we had a pointer to a struct, recall that we could access
      // its fields in two ways:
      //
      // struct T *struct_ptr = &data;
      //
      // struct_ptr->gl = 597;
      // (*struct_ptr).gl = 597;
      //
      // ^ Both of those expressions are semantically equivalent.

      return 0;
   }



// ===========================================================================
// I sometimes also cover the following lightning review problems before my
// file I/O lecture, but you've already seen these problems this semester.
// ===========================================================================

// ===========================================================================
// 2. Write a function called swap() that takes two integer pointers and swaps
//    the values they point to.
// ===========================================================================
   void swap(int *a, int *b)
   {
      int temp = *a;
      *a = *b;
      *b = temp;
   }

// ===========================================================================
// 3. Dynamically allocate an array of n integers. Properly declare the array
//    variable, as well.
// ===========================================================================

   int n;
   int *array;

   // ... Presumably, we would read a value for n here ...

   // Recall that arrays are contiguous in memory. We're setting aside one big
   // chunk of memory that is large enough to hold n integers.
   array = malloc(sizeof(int) * n);


// ==========================================================================
// 3. Dynamically allocate a string that can hold a name that has 10 letters.
//    Give the appropriate declaration for the variable holding the string.
// ==========================================================================

   char *str;
   int n = 10;

   // Don't forget the extra space for the null terminator, '\0'.
   str = malloc(sizeof(char) * (n + 1));


// ==========================================================================
// Side note: The following is TERRIBLE. Don't return the address of a
// statically allocated variable. Statically allocated variables DIE as the
// function returns, so it's dangerous to keep a pointer to them. That memory
// could be reclaimed, repurposed, and reused at any moment.
// ==========================================================================

	struct T *create_a_struct(void)
	{
	   struct T t;
	   return &t;  // :(
	}
