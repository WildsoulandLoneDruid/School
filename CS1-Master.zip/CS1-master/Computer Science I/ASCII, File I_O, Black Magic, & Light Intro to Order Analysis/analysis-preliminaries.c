// Sean Szumlanski
// COP 3502, Spring 2018

// analysis-preliminaries.c
// ========================
// A very light, very basic intro to the idea of Big-Oh notation.


// In discussing runtimes for segments of code (or entire functions), we first
// saw that comparing actual runtimes is a bad idea for a number of reasons.
// Instead, we developed a framework for theoretical runtime analysis.

// In terms of theoretical runtime analysis, we started with this approach,
// which is on the right track, but has some key problems: In this approach,
// we are interested in counting the number of steps or instructions executed.
// For foo0(), let's count:
//
// 1. Assignment statements
// 2. Comparisons
// 3. Arithmetic operations

int foo0(int *array, int n)
{
	int i, sum = 0;

	for (i = 0; i < n; i++)
		sum += array[i];

	return sum;
}

// sum = 0   --- executed once.
// i = 0     --- executed once.
// i < n     --- executed (n + 1) times (Do you see why it's (n + 1) and not n?)
// i++       --- executed n times
// sum +=... --- executed n times
//
// Note: We could consider sum += array[i] two operations if we wanted to, but
// we'll see shortly that this doesn't really matter for the kind of analysis
// we'll be doing.

// Total: T(n) = 3n + 3
//
//        ^ Notice that this runtime is written as a function, T, of some input
//          variable, n. This is the variable (or, in some cases, just one of
//          multiple variables) that affects the runtime. It other cases, it
//          might be the length of an array, an integer we want to manipulate,
//          the number of elements in a linked list, etc.
//
// Here are some problems with our runtime:
//
// 1.) It's very easy to mis-count our terms! Should the += operation count as
//     one or two? Are there other places where we need to worry about this?
//     What exactly counts as an instruction? Should we include declarations in
//     our count? What about the cost of accessing array[i] so that we can add
//     it to our sum? There are simply too many possibilities for us to consider
//     all of them with great precision.
//
// 2.) Differences in constants can be misleading because different
//     architectures reduce these to different numbers of low-level processor
//     instructions.
//
//     E.g., T1(n) = 3n^2 + 5, T2(n) = 6n^2 + 5
//
//                                     ^ What if these particular instructions
//                                       are actually *faster* to execute on
//                                       my processor than the ones in T1? I.e.,
//                                       they only take two cycles instead of
//                                       three?
//
// 3.) It's rather pointless to focus on lower-order terms, isn't it? As n
//     approaches any sort of meaningful (i.e., LARGE) input size, the lower-
//     order terms become irrelevant.


// Let's discuss...
//
//         O R D E R   A N A L Y S I S
//              (" B I G - O H ")
//
//                           ^ Hey, this is a big deal!


// Big-Oh frees us from the problems listed above. We saw that we drop
// coefficients and focus on the highest-order term in each runtime. Here are
// some examples:

// For foo0(), T(n) = 3n + 3, which is O(n)

// T1(n) = n + 3(n^3) + 2(n^2) + 1055     =>  O(???)   (fill in the blank)
// T2(n) = (1/6)(n^3) + 1000(n^2)         =>  O(n^3)
// T3(n) = n log n + log n + n            =>  O(???)   (fill in the blank)
// T4(n) = sqrt(n) + 4n + 16(log n) + 23  =>  O(n)
// T5(n) = sqrt(n) + log(n)               =>  O(???)   (which one grows faster?)
// T6(n) = 50                             =>  O(1)

// Note:
// When a runtime is constant, we drop that coefficient and just write that
// the big-oh runtime is O(1). For example, the following function has
// constant runtime (it does not change even if the array is very large),
// so we would write that its runtime is O(1) (not O(50)):
//
// int foo(int *array, int n)
// {
//    int i;
//    for (i = 0; i < 50; i++)
//       printf("Hooray!\n");
//    return n;
// }
//
// ^ I'll discuss that more in our next class. :)
