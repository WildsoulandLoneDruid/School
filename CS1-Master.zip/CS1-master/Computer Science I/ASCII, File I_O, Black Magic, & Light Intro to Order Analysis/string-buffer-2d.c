// Sean Szumlanski
// COP 3502, Spring 2018

// string-buffer-2d.c
// ==================
// This is an advanced version of string-buffer-basic.c that reads strings from
// a file and stores them in a dynamically allocated 2D array. The program
// assumes that the first line of the file contains a single integer indicating
// how many strings there are in the remaining lines of the file. For example:
//
//       4
//       Robb
//       Arya
//       Bran
//       Dany

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	int i, n;

	char filename[32];
	char buffer[1024];

	// For a 2D array (an array of strings, which is an array of char arrays).
	char **strings;

	FILE *ifp;

	if ((ifp = fopen("input.txt", "r")) == NULL)
	{
		fprintf(stderr, "Failed to open input file in main()!\n");
		return 0;
	}

	// Scan the number of strings we'll be reading and create an array to hold
	// the char pointer for each of those strings.
	fscanf(ifp, "%d", &n);
	strings = malloc(sizeof(char *) * n);

	for (i = 0; i < n; i++)
	{
		fscanf(ifp, "%s", buffer);

		// Create exactly enough space to hold this string elsewhere in memory.
		// strlen() returns the number of characters in a string, and does NOT
		// account for the null terminator, so you still need to +1.
		strings[i] = malloc(sizeof(char) * (strlen(buffer) + 1));

		// Copy the buffer's contents into the newly allocated space.
		strcpy(strings[i], buffer);

		// This is just for debugging purposes.
		printf("String (from file): %s\n", buffer);
	}

	// Now print out the array's contents (and free those strings as we go).
	printf("\nArray contents:\n");

	for (i = 0; i < n; i++)
	{
		printf("string[%d]: %s\n", i, strings[i]);
		free(strings[i]);
	}

	// Finally, free the array itself and close the input file.
	free(strings);
	fclose(ifp);

	return 0;
}
