// Sean Szumlanski
// COP 3502, Spring 2018

// string-buffer-basic.c
// =====================
// This includes some basic file I/O. For more, see file-read.c, attached as a
// supplement to today's notes.
//
// This code demonstrates how to read from a file until you hit the end of that
// file (EOF), and how to use strlen() in conjunction with malloc() to dynamically
// allocate space for strings. It also has a comment on how to squash what would
// have been a nasty memory leak in the while-loop.
//
// Not all of this was covered in class in detail, but the code is here for you
// if you want to learn from it.


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	int i;

	// I'll restrict my filenames to 20 characters.
	char filename[21];

	// I'll restrict the strings in my input file to 800 characters.
	char buffer[801];

	// I'll use this to hold strings in dynamically allocated space.
	char *word;

	FILE *ifp = NULL;

	// Side Note: In C, assignment statements evaluate to the value being
	// assigned. This will print out 17.
	printf("%d\n", i = 17);

	// Using a variable to store the name of your input file will enable you to
	// print useful error messages about that file in the event that if fails to
	// open.
	strcpy(filename, "input.txt");

	// fopen() returns NULL if it fails to open the file. If that's the case,
	// then the assignment (ifp = fopen(...)) will evaluate to NULL, and the
	// comparison will evaluate to true.
	if ((ifp = fopen(filename, "r")) == NULL)
	{
		fprintf(stderr, "Could not open %s in main()!\n", filename);
		exit(0);
	}

	// fscanf() returns EOF when it hits the end of a file. Let's keep reading
	// until we hit the end of that file.
	while (fscanf(ifp, "%s", buffer) != EOF)
	{
		// Create exactly enough space to hold this string elsewhere in memory.
		// strlen() returns the number of characters in a string, and does NOT
		// account for the null terminator, so you still need to +1.
		word = malloc(sizeof(char) * (strlen(buffer) + 1));

		// Copy the buffer's contents into the newly allocated space.
		strcpy(word, buffer);

		// If you encounter trouble with file I/O, one of the first things you
		// should do is print everything that you're reading, just to make sure
		// your scanf() is working properly. (Here, you could also print the
		// contents of 'buffer' if you're having trouble debugging your code.)
		printf("(read string) %s\n", word);

		// Check your understanding: Do you see why this code has a nasty memory
		// leak if you eliminate this free() statement?
		free(word);
	}
	// There's no need to set word = NULL inside the while-loop, because we'll
	// just overwrite it in the next iteration of the loop. However, when we
	// break out of the loop, we know word points nowhere useful. It's good
	// practice to set it to NULL, accordingly.
	word = NULL;

	// It's good practice to close files when you're finished with them and then
	// set their file pointers to NULL. (This isn't so important when you're
	// about to exit the program, but in case you ever want to re-purpose this
	// main() function for something else, it would be nice to know that it's
	// free of memory leaks.)
	fclose(ifp);
	ifp = NULL;

	return 0;
}
