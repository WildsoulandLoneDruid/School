// Sean Szumlanski
// COP 3502, Spring 2018
//
// linked-lists.c
// ==============
// Adapted from class on Monday, Feb. 5.


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Basic linked list node struct; contains 'data' and 'next' pointer.
// What happens if we type "node *next" instead of "struct node *next"?
typedef struct node
{
	int data;
	struct node *next;
} node;

// Returns the address of a dynamically allocated node after properly
// initializing all its fields.
node *create_node(int data)
{
	node *ptr = malloc(sizeof(node));

	if (ptr == NULL)
	{
		fprintf(stderr, "Error: Out of memory in create_node()\n");
		exit(1);
	}

	ptr->data = data;
	ptr->next = NULL;

	return ptr;
}

// Insert at the tail of the linked list and return the head of the list.
// What is the order (i.e., big-oh runtime) of this function?
node *tail_insert(node *head, int data)
{
	node *temp;

	// If the head is NULL, we create a node and return head. We want to ship the
	// address of the new head node back to main() (or wherever we call this
	// function from) so we can refer to the list from there.
	if (head == NULL)
		return create_node(data);

	// If there are elements in the list, skip forward to the last (non-NULL)
	// element. There are many different ways to write this loop.
	for (temp = head; temp->next != NULL; temp = temp->next)
		;

	// 'temp' is pointing to the last node in the list now. So, to add a node
	// to the end, set temp->next to the new node we're creating.
	temp->next = create_node(data);
	return head;
}

// This just shows another way to set up the loop.
node *alternate_tail_insert(node *head, int data)
{
	node *temp;

	if (head == NULL)
		return create_node(data);

	temp = head;
	while (temp->next != NULL)
		temp = temp->next;

	// 'temp' is pointing to the last node in the list now.
	temp->next = create_node(data);
	return head;
}

// Simple function to print the contents of a linked list.
void print_list(node *head)
{
	node *temp;

	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	for (temp = head; temp != NULL; temp = temp->next) 
		printf("%d%c", temp->data, (temp->next == NULL) ? '\n' : ' ');
}

// A recursive function to print a linked list. It's called by the
// print_list_recursive() function defined below. (This is a preview. This
// function will be covered on Wednesday.)
void print_list_recursive_helper(node *head)
{
	if (head == NULL)
		return;

	printf("%d%c", head->data, (head->next == NULL) ? '\n' : ' ');
	print_list_recursive_helper(head->next);
}

// This function acts as a gatekeeper to our recursive printing function. If the
// list is empty, it just prints "(empty list)" and returns. Otherwise, it calls
// the recursive function. If we print "(empty list)" as part of the base case
// of our recursive version, the output would always include that on the final
// recursive call -- even if the original list wasn't empty.
void print_list_recursive(node *head)
{
	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}
	print_list_recursive_helper(head);
}

int main(void)
{
	int i, r;

	// The head of our linked list. If we don't initialize it to NULL, our
	// tail_insert() function might segfault.
	node *head = NULL;

	srand(time(NULL));

	// Populate the linked list with random integers. We are inserting into the
	// head of the list each time.
	for (i = 0; i < 10; i++)
	{
		printf("Inserting %d...\n", r = rand() % 20 + 1);
		head = tail_insert(head, r);
	}

	// Print the linked list.
	print_list(head);

	// Print the linked list using our recursive function.
	print_list_recursive(head);

	return 0;
}
