// Sean Szumlanski
// COP 3502, Spring 2018

// crystal_etching.c
// =================
// A program that uses binary search to solve the crystal etching problem
// presented in class.
//
// Use the -lm flag to compile:
//
//    gcc crystal_etching.c -lm


#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define EPSILON 0.000001

double fval(double a, double b, double c, double t)
{
	return a * t + b * (1.0 - exp(-1.0 * c * t));
}

double solve_for_t(double f1, double f2, double a, double b, double c)
{
	double lhs = (f2 - f1) / (f2 * f1);
	double rhs;

	// The mid will be our hypothesis, which is time t.
	double lo = 0.0, hi = 10000.0, t;

	while (hi - lo > EPSILON)
	{
		// Find midpoint.
		t = lo + (hi - lo) / 2.0;

		rhs = fval(a, b, c, t);

		if (lhs < rhs)
			hi = t;

		else if (lhs > rhs)
			lo = t;

		else
			return t;
	}

	return lo + (hi - lo) / 2.0;
}

int main(void)
{
	double t;

	// Expected result (from Arup's PDF): 0.57
	t = solve_for_t(500.0, 1000.0, .001, .001, 1.0);
	printf("t: %.2f\n", t);

	// Expected result (from Arup's PDF): 1.00
	t = solve_for_t(1000.0, 2000.0, .00025, .0005, 0.6931472);
	printf("t: %.2f\n", t);

	return 0;
}
