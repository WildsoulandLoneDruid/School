// Sean Szumlanski
// COP 3502, Spring 2018

// exam2-review-packet-functions.c
// ===============================
// Solutions to the binary tree problems from the Exam #2 review packet.


////////////////////////////////////////////////////////////////////////////////
// SPOILER ALERT! We did not cover all of these functions in class. You should
// try writing these functions on your own before reading through the solutions.
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <stdlib.h>

// basic binary tree node
typedef struct node
{
	int data;
	struct node *left, *right;
} node;


// Takes the root of a BST and returns a pointer to the node with the max value
// in that tree. (Recursive version.)
node *largest(node *root)
{
	if (root == NULL)
		return NULL;

	if (root->right == NULL)
		return root;

	return largest(root->right);
}

// Takes the root of a BST and returns a pointer to the node with the max value
// in that tree. (Iterative version.)
node *iterative_largest(node *root)
{
	if (root == NULL)
		return NULL;

	while (root->right != NULL)
		root = root->right;

	return root;
}

// Returns the number of leaf nodes in this binary tree.
int count_leaf_nodes(node *root)
{
	int count;

	if (root == NULL)
		return 0;

	if (root->left == NULL && root->right == NULL)
		return 1;
	else
		return count_leaf_nodes(root->left) + count_leaf_nodes(root->right);
}

// Returns the number of nodes in this tree that have a single child.
int count_one_child(node *root)
{
	// If root is NULL, this (sub)tree is empty and has no single-child nodes.
	if (root == NULL)
		return 0;

	// If this node has no children, we've reached the end of the line.
	else if (root->left == NULL && root->right == NULL)
		return 0;

	// Notice that if we reach this line, we know that the node has at least one
	// child. (They can't both be NULL, because that case was handled on line
	// 29.) So, if we find that one of the children is NULL here, we know that
	// *exactly* one child is NULL. Thus, root has a single child and we
	// increment our count accordingly.
	else if (root->left == NULL || root->right == NULL)
		return 1 + count_one_child(root->left) + count_one_child(root->right);

	// Otherwise, this node has two children, so we just add up the nodes in its
	// left and right subtrees that have exactly one child.
	else
		return count_one_child(root->left) + count_one_child(root->right);
}

// A slightly fancier version of the count_one_child() function.
int count_one_child_FANCY(node *root)
{
	// empty tree
	if (root == NULL)
		return 0;

	// no children
	else if (root->left == NULL && root->right == NULL)
		return 0;

	// Notice that if (root->left == NULL || root->right == NULL) evaluates to
	// "true," C treats is as the value 1. If it evaluates to "false," C treats
	// it as the value 0. So, we can just add that to our recursive calls! This
	// collapses lines 38-39 and 43-44 (above) into a single statement:
	return (root->left == NULL || root->right == NULL) +
	       count_one_child_FANCY(root->left) + count_one_child_FANCY(root->right);
}

// Recursive function to count how many nodes in a binary search tree have
// value greater than 'key'.
int BST_count_greater(node *root, int key)
{
	// Clearly, if the tree is empty, there are no such nodes.
	if (root == NULL)
		return 0;

	// If this node's value is greater than 'key', then there might be more
	// such nodes in its left and right subtrees. (Consider, for example, the
	// following tree, where key = 29:
	//
	//     100
	//    /   \
	//   50   150
	//
	// Notice that there are values <29 in the left *and* right subtrees of 100.
	else if (root->data > key)
		return 1 + BST_count_greater(root->left, key)
	            + BST_count_greater(root->right, key);

	// On the other hand, if root->data < key, we know all values in the root's
	// left subtree are necessarily <key as well. Thus, we can potentially
	// reduce the amount of computation by *only* searching the right subtree
	// for values >key in this case. (Of course, if the left subtree is empty,
	// we have no runtime savings. If it's huge, though, we can save a lot.)
	else
		return BST_count_greater(root->right, key);
}

// Takes the roots of two trees and returns 1 if they differ (in terms of their
// structure and/or the values they contain). Otherwise, return 0.
int tree_diff(node *a, node *b)
{
	// The empty trees are the same. (No difference, so return 0.)
	if (a == NULL && b == NULL)
		return 0;

	// If one tree is empty but not the other, they are necessarily different.
	else if (a == NULL || b == NULL)
		return 1;

	// If the data at the nodes being compared is different, the trees differ.
	else if (a->data != b->data)
		return 1;

	// If either one (or both) of these calls returns 1, then the trees differ.
	// Otherwise, they are identical.
	return tree_diff(a->left, b->left) || tree_diff(a->right, b->right);
}
