// Sean Szumlanski
// COP 3502, Spring 2018

// additional-binary-tree-examples.c
// =================================
// Some additional examples of binary tree functions. Some of these we've seen
// before, and some are new. There's all kinds of good stuff here. :)


#include <stdio.h>
#include <stdlib.h>

#define OH_NOOOO 1
#define HOORAY 0

typedef struct node
{
	int data;
	struct node *left, *right;
} node;

// Write a function that takes the root of a BST, 'root', and an integer,
// 'key', and returns 1 if the BST contains 'key'. Otherwise, return 0.
int BST_search(node *root, int key)
{
	if (root == NULL)
		return 0;

	if (key < root->data)
		return BST_search(root->left, key);
	else if (key > root->data)
		return BST_search(root->right, key);

	return 1;
}

// An iterative version of BST search. This essentially uses 'root' as a temp
// pointer. Because we don't have to descend into the left *and* right subtrees
// at each node, recursion is not necessary to solve this problem.
int BST_search_iterative(node *root, int key)
{
	while (root != NULL)
	{
		if (key < root->data)
			root = root->left;
		else if (key > root->data)
			root = root->right;
		else
			return 1;
	}

	return 0;
}

// Write a function that takes the root of a binary tree, 'root', and an
// integer 'key', and returns 1 if the tree contains 'key'. Otherwise,
// return 0.
int regular_binary_tree_search(node *root, int key)
{
	if (root == NULL)
		return 0;

	if (key == root->data)
		return 1;

	// short circuiting
	return (regular_binary_tree_search(root->left, key) ||
	        regular_binary_tree_search(root->right, key));
}

// Write a function that takes the root of a binary tree, 'root', and an
// integer 'key', and returns how many times 'key' appears in the tree.
int key_count(node *root, int key)
{
	if (root == NULL)
		return 0;

	if (root->data == key)
		return 1 + key_count(root->left, key) + key_count(root->right, key);
	else
		return key_count(root->left, key) + key_count(root->right, key);
}

int key_count_fancy(node *root, int key)
{
	if (root == NULL)
		return 0;

	return (root->data == key) + key_count_fancy(root->left, key) + key_count_fancy(root->right, key);
}

// Write a function that takes the root of a binary tree as its sole argument
// and returns the number of nodes in that tree.
int count_nodes(node *root)
{
	if (root == NULL)
		return 0;

	return 1 + count_nodes(root->left) + count_nodes(root->right);
}

// Write a function that takes the root of a binary tree as its sole argument
// and returns the number of nodes in that tree that have exactly one child.
int count_one_child_nodes(node *root)
{
	if (root == NULL)
		return 0;

	if ((root->left != NULL && root->right == NULL) || (root->left == NULL && root->right != NULL))
		return 1 + count_one_child_nodes(root->left) + count_one_child_nodes(root->right);
	else
		return count_one_child_nodes(root->left) + count_one_child_nodes(root->right);
}

int count_one_child_nodes_alt(node *root)
{
	int val = 0;

	if (root == NULL)
		return 0;

	if ((root->left != NULL && root->right == NULL) || (root->left == NULL && root->right != NULL))
		val = 1;

	return val + count_one_child_nodes_alt(root->left) + count_one_child_nodes_alt(root->right);
}

// This version capitalizes on the fact that if we have a node with exactly one child,
// we should really only need to call the function recursively on that non-NULL child,
// not on both children (since one of them is the root of an empty subtree).
int count_one_child_nodes_fancy(node *root)
{
	if (root == NULL)
		return 0;

	else if (root->left != NULL && root->right == NULL)
		return 1 + count_one_child_nodes_fancy(root->left);

	else if (root->left == NULL && root->right != NULL)
		return 1 + count_one_child_nodes_fancy(root->right);

	else
		return count_one_child_nodes_fancy(root->left) + count_one_child_nodes_fancy(root->right);
}

// Little helper function. So short. So cute.
int max(int a, int b)
{
	return (a > b) ? a : b;
}

// Write a function that takes the root of a binary tree as its sole argument
// and returns the height of that tree.
int height(node *root)
{
	if (root == NULL)
		return -1;

	return 1 + max(height(root->left), height(root->right));
}

int height_excessively_fancy(node *root)
{
	return (root == NULL) ? -1 : 1 + max(height(root->left), height(root->right));
}

// Write a function that takes the root of a BST as its sole argument
// and returns 1 if the BST contains any negative values. Otherwise,
// return 0. Note: "HOORAY" is synonymous with no negativity (0). "OH_NOOOO" is
// synonymous with negativity (1).
//
// Space Complexity: O(n) (because of the call stack's growth)
int has_some_negativity_in_its_life(node *root)
{
	if (root == NULL)
		return HOORAY;

	if (root->data < 0)
		return OH_NOOOO;

	// If root->data was non-negative, then all the stuff in its right subtree
	// (which is bigger than root->data) must also be non-negative. Therefore,
	// we only recursively descend into the left subtree in our search for
	// negative values.
	return has_some_negativity_in_its_life(root->left);
}

// Space Complexity: O(1) (because we only create a single root pointer; that's it)
int has_some_negativity_in_its_life_iterative(node *root)
{
	while (root != NULL)
	{
		if (root->data < 0)
			return OH_NOOOO;

		root = root->left;
	}

	return HOORAY;
}
