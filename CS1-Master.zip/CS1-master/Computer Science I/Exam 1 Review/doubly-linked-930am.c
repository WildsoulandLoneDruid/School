// Sean Szumlanski
// COP 3502, Spring 2018

// doubly-linked-930am.c
// =====================
// From the 9:30 AM class. I haven't carefully vetted this code.


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct node
{
	int data;	
	struct node *next;
	struct node *prev;
} node;

node *create_node(int data)
{
	node *n = malloc(sizeof(node));
	n->data = data;
	n->next = NULL;
	n->prev = NULL;
	return n;
}

// Inserts at tail of linked list. Always returns new tail of list.
node *tail_insert(node *tail, int data)
{
	if (tail == NULL)
		return create_node(data);

	tail->next = create_node(data);
	tail->next->prev = tail;
	return tail->next;
}


void print_list(node *head)
{
	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	while (head != NULL)
	{
		printf("%d ", head->data);
		head = head->next;
	}

	printf("\n");
}

// Inserts at tail of linked list. Always returns new tail of list.
node *tail_delete(node *tail)
{
	node *new_tail;

	if (tail == NULL)
		return NULL;

	new_tail = tail->prev;
	free(tail);

	if (new_tail != NULL)
		new_tail->next = NULL;

	return new_tail;
}

int main(void)
{
	int i, r, n = 5;
	node *head = NULL, *tail = NULL;

	srand(time(NULL));

	for (i = 0; i < n; i++)
	{
		printf("Inserting %d...\n", r = rand() % 78 + 1);
		tail = tail_insert(tail, r);

		if (head == NULL)
			head = tail;
	}

	printf("The initial list is:\n");
	print_list(head);

	printf("\nLet's delete the tails one by one:\n");

	while (head != NULL)
	{
		tail = tail_delete(tail);

		if (tail == NULL)
			head = NULL;

		print_list(head);
	}

	return 0;
}
