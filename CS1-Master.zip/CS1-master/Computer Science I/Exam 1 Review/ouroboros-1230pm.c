// Sean Szumlanski
// COP 3502, Spring 2018

// ouroboros-1230pm.c
// ==================
// From the 12:30 PM class. I haven't carefully vetted this code.


#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int data;
	struct node *next;
} node;

node *create_node(int data)
{
	node *n = malloc(sizeof(node));
	n->data = data;
	n->next = NULL;
	return n;
}

void print_list(node *head)
{
	node *temp = head;

	if (head == NULL)
	{
		printf("(empty list)\n");
		return;
	}

	do
	{
		printf("%d ", temp->data);
		temp = temp->next;
	} while (temp != head);

	printf("\n");
}

// Return the head of the list.
node *tail_insert(node *head, int data)
{
	node *temp;
	node *new_tail = create_node(data);

	if (head == NULL)
	{
		new_tail->next = new_tail;
		return new_tail;
	}

	for (temp = head; temp->next != head; temp = temp->next)
		;

	temp->next = new_tail;

	new_tail->next = head;

	return head;
}

int main(void)
{
	node *head = NULL;

	head = tail_insert(head, 12);
	head = tail_insert(head, 44);
	head = tail_insert(head, 58);

	print_list(head);

	return 0;
}
