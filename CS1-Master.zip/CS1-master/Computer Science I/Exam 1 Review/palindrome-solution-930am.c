// Sean Szumlanski
// COP 3502, Spring 2018

// palindrome-solution-930am.c
// ===========================
// Solution to the isPalindrome() question from the practice exam. This was
// covered in the 9:30 AM class.


int isPalindrome(char *str, int n)
{
	if (n < 2)
		return 1;

	if (str[0] != str[n-1])
		return 0;

	return isPalindrome(str + 1, n - 2);		
}
