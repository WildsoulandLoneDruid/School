#include "stdio.h"
#include "stdlib.h"

#define NAME_DEFAULT 20
#define DEFAULT_CAPACITY 20
#define INPUT_LIMIT 100
#define FAILURE 0
#define SUCCESS 1

typedef struct Author_T
{
  char name[NAME_DEFAULT];
  int birthYear;
  int publishings;
} Author_T;

typedef struct Book_T
{
  char name[NAME_DEFAULT];
  int capacity;
  int year;
  int numAuthors;
  Author_T * authors;
}Book_T;

Author_T * DefaultAuthor()
{
  Author_T * NewAuthor = calloc(1,sizeof(Author_T));
  if(NewAuthor != NULL)
  {
    NewAuthor -> name;
    NewAuthor -> birthYear = 0;
    NewAuthor -> publishings = 0;
  }
  else
  {
    NewAuthor = NULL;
  }
  return NewAuthor;
}

Book_T * DefaultBook()
{
  Book_T * NewBook = calloc(1,sizeof(Book_T));
  if(NewBook != NULL)
  {
    NewBook -> name;
    NewBook -> capacity = DEFAULT_CAPACITY;
    NewBook -> year = 0;
    NewBook -> numAuthors;
    NewBook -> authors = DefaultAuthor();
  }
  else
  {
    NewBook = NULL;
  }
  return NewBook;
}

int AddBook(Book_T * , char [])
{

}



int main(void)
{
  int numOfBooks = 0;
  Book_T * book;
  book = DefaultBook();
  char input [INPUT_LIMIT];

  printf("How many books are you storing?\n");
  scanf("%d",&numOfBooks);
  for (int i = 0; i < numOfBooks; i++)
  {
    printf("Book Information\n");
    scanf("%[^\n]",input);

  }





  return 0;
}
