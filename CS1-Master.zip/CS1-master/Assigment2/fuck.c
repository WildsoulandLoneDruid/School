#include<stdio.h>

#include<stdlib.h>

#include<string.h>



#define SUCCESS 1

#define FAILURE -1



#define TRUE (1==1)

#define FALSE (!TRUE)



#define DEFAULT_CAP 5



typedef struct name

{

    char * str; // Just a string

} name;



typedef struct array_list

{

    name * arr; // array of names

    int size, cap;

} array_list;



typedef struct full_list

{

    array_list * aol; // array of (array)lists

    int size, cap;

} full_list;



// functions


int add_al(array_list * al, name *);

int add_fl(full_list * al, array_list * arl, name * adder);

int expand_al(array_list *);

int expand_fl(full_list *);

name * newName();

array_list * newArray_List();

full_list * full_list_students();

full_list * full_list_symptoms();

int string_compare (full_list * stud, full_list * symp,name * studName, name* studSymp, char * name, char * symps);




int expand_al(array_list * al)

{

    int newCap = al->cap + 2;

    name * newList = (name *)realloc(al->arr, newCap * sizeof(name));



    if (newList == NULL)

    {

        return FAILURE;

    }



    al->cap = newCap;

    al->arr = newList;



    return SUCCESS;

}



int expand_fl(full_list * al)

{

    int newCap = al->cap + 2;

    array_list * newLists = (array_list*)realloc(al->aol, newCap * sizeof(array_list));



    if (newLists == NULL)

    {

        return FAILURE;

    }



    al->cap = newCap;

    al->aol = newLists;



    return SUCCESS;

}



int add_al(array_list * al, name * names)

{

    if (al->cap == al->size)

    {

        if(expand_al(al) == FAILURE)

        {

            return FAILURE;

        }

    }



    al->arr[al->size] = * names;

    al->size++;



    return SUCCESS;

}



int add_fl(full_list * al, array_list * arl, name * adder)

{

    if (al->cap == al->size)

    {

        if(expand_fl(al) == FAILURE)

        {

            return FAILURE;

        }

    }



    add_al(arl, adder);

    al->aol[al->size] = * arl;

    al->size++;

    return SUCCESS;

}



name * newName(char * str)

{

    int i;

    name * names = (name *)calloc(1, sizeof(name));



    if (names != NULL)

    {

        names->str = (char *)calloc(101, sizeof(char));

        if (names->str == NULL)

        {

            free(names);

            names = NULL;

        }

    }



    strcpy(names->str, str);



    return names;

}



array_list * newArray_List()

{

    int i;



    array_list * arrayNames = (array_list *)calloc(1, sizeof(array_list));



    if (arrayNames != NULL)

    {

        arrayNames->arr = (name *)calloc(arrayNames->cap, sizeof(name));

        arrayNames->cap = DEFAULT_CAP;

        arrayNames->size = 0;



        if (arrayNames->arr == NULL)

        {

            free(arrayNames);

            arrayNames = NULL;

        }

    }



    return arrayNames;

}



full_list * full_list_students()

{

    full_list * stud = (full_list *)calloc(1, sizeof(full_list));



    if (stud == NULL)

    {

        return stud;

    }



    stud->size = 0;

    stud->cap = DEFAULT_CAP;



    stud->aol = (array_list *)calloc(1, sizeof(array_list));



    if (stud->aol == NULL)

    {

        free(stud);

        stud = NULL;

    }



    return stud;

}



full_list * full_list_symptoms()

{

    full_list * symp = (full_list *)calloc(1, sizeof(full_list));





    if (symp == NULL)

    {

        return symp;

    }



    symp->size = 0;

    symp->cap = DEFAULT_CAP;



    symp->aol = (array_list *)calloc(1, sizeof(array_list));



    if (symp->aol == NULL)

    {

        free(symp);

        symp = NULL;

    }



    return symp;

}



int string_compare (full_list * stud, full_list * symp,name * studName, name* studSymp, char * name, char * symps)

{



    studName = newName(name);

    studSymp = newName(symps);



    int flag = 0;

    int i;



    for (i = 0; i < stud->size; i++)

    {

        if (strcmp(stud->aol[i].arr[0].str, studName->str) == 0)

        {

            add_al(&stud->aol[i], studSymp);

            flag = 1;

        }

        if (strcmp(symp->aol[i].arr[0].str, studSymp->str) == 0)

        {

            add_al(&symp->aol[i], studName);

            flag = 1;

        }

        flag = 0;

    }



    if (flag == 0)

    {

        array_list * arrayList2 = newArray_List();

        add_fl(stud, arrayList2, studName);

        add_al(&stud->aol[i], studSymp);

        array_list * arrayList3 = newArray_List();

        add_fl(symp, arrayList3, studSymp);

        add_al(&symp->aol[i], studName);

    }

}

int locationFinder(full_list * al, char * string1)
{
     name * string2 = newName(string1);

     int i;
     for (i = 0; i < al->size; i++)
     {
          if (strcmp(al->aol[i].arr[0].str, string2->str) == 0)
          {
            return i;
          }
     }
}


int main()

{

    int i;

    int m;

    char letter;

    char student[101];

    char symptom[101];



    full_list *flstud = full_list_students();

    full_list *flsymp = full_list_symptoms();

    name * studName;

    name * studSymp;



    scanf("%d", &m);
    printf("%d\n", m);

    for (i = 0; i < m; i++)
    {
      scanf("%s", &letter);
      printf("HERE\n\n");

        if (letter == 'u')

        {


            string_compare(flstud, flsymp,studName,studSymp, "john", "laughed");

            printf("%s\n",flstud->aol[0].arr[0].str);

            printf("%s\n",flstud->aol[0].arr[1].str);

            printf("%s\n",flsymp->aol[0].arr[0].str);

            printf("%s\n",flsymp->aol[0].arr[1].str);

        }

        else
        {
          printf("HERE2\n\n");
        }

  }


    return 0;

}
