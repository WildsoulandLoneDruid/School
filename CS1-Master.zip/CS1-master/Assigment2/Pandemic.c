#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define DEFAULT_CAPACITY 100
#define MAX_STRING_CAPACITY 101     //101 + 101 + 2 + 1 (possbily an addtional 3)
#define SUCCESS 1
#define FAILURE 0

typedef struct name
{
  char * str;
}name;

typedef struct arrayList
{
  name * arr;
  int arrayListSize;
  int arrayListCapacity;
}arrayList;

typedef struct fullList
{
  arrayList * aol;
  int fullListSize;
  int fullCapacity;
} fullList;

fullList * newSympList ()
{
  fullList * newSymp = calloc(1,sizeof(fullList));
  newSymp -> aol = (arrayList *) calloc (DEFAULT_CAPACITY,sizeof(arrayList));
  newSymp -> fullListSize = 0;
  newSymp -> fullCapacity = DEFAULT_CAPACITY;
  if(newSymp -> aol == NULL)
  {
    free(newSymp);
    newSymp = NULL;
  }
  return newSymp;
}

/*
fullList * newNameList ()
{
  fullList * newName = calloc(1,sizeof(fullList));
  newName -> aol = (arrayList *) calloc (DEFAULT_CAPACITY,sizeof(arrayList));
  newName -> fullListSize = 0;
  newName -> fullCapacity = DEFAULT_CAPACITY;
  if(newName -> aol == NULL)
  {
    free(newName);
    newName = NULL;
  }
  return newName;
} */
arrayList * newArrayList()
{
  arrayList * newArray = calloc(1,sizeof(arrayList));
  if(newArray != NULL)
  {
    newArray -> arrayListSize = 0;
    newArray -> arrayListCapacity = DEFAULT_CAPACITY;
    newArray -> arr = calloc(MAX_STRING_CAPACITY, sizeof(name));
    if(newArray -> arr == NULL)
    {
      free(newArray);
      newArray = NULL;
    }
  }
  return newArray;
}

name * makeData (char * str2)
{
  name * newData = calloc(1,sizeof(name));
  newData -> str = malloc(101 * sizeof(char));
  strcpy(newData -> str, str2);

  return newData;
}


int expandFullList(fullList * fl)
{
  int newCap = fl -> fullCapacity + 1;
  arrayList * newAol = realloc (fl -> aol, newCap * sizeof(arrayList));
  if(newAol == NULL)
  {
    return FAILURE;
  }
  fl -> fullCapacity = newCap;
  fl -> aol = newAol;
  return SUCCESS;
}

int expandArrayList(arrayList * al)
{
  int newCap = al -> arrayListCapacity * 2;
  name * newArr = realloc (al -> arr, newCap * sizeof(name));
  if(newArr == NULL)
  {
    return FAILURE;
  }
  al -> arrayListCapacity = newCap;
  al -> arr = newArr;

  return SUCCESS;
}

int addArrayList(arrayList * al, name * adding)
{
  if(al -> arrayListSize == al -> arrayListCapacity )
  {
    expandArrayList(al);
  }
  al -> arr[al->arrayListSize] = *adding;
  al -> arrayListSize++;
    return SUCCESS;
}

int addFullList (fullList *fl, name * adding)
{
  if(fl -> fullListSize == fl -> fullCapacity )
  {
    expandFullList(fl);
  }
  arrayList * ArrayList = newArrayList();
  addArrayList(ArrayList,adding);
  fl->aol[fl->fullListSize] = *ArrayList;
  fl->fullListSize++;
  return SUCCESS;
}

void update (fullList * student, fullList * symp, char * name2  , char  * symptom)
{
  name * studentName = makeData(name2);
  name * studentSymp = makeData(symptom);
  int flag = 0;

  for (int i = 0; i < student -> fullListSize;i++)
  {
    if(strcmp(student->aol[i].arr[0].str,studentName->str)==0)
    {
      flag = 1;
      addArrayList(&student -> aol[i],studentSymp);
    }
    if(strcmp(symp->aol[i].arr[0].str,studentSymp->str)==0)
    {
      flag = 1;
      addArrayList(&symp -> aol[i],studentName);
    }

    }
    if (flag == 0)
    {
      addFullList(student,studentName);
      addArrayList(&student -> aol[student -> fullListSize - 1],studentSymp);
      addFullList(symp,studentSymp);
      addArrayList(&symp -> aol[symp -> fullListSize - 1],studentName);
    }

  flag = 0;
}

int findRow(fullList * mat,char * data)
{
  name * dataCheck = makeData(data);
  int i = 0;
  for(i = 0; i < mat -> fullListSize; i++)
  {
    if(strcmp(mat->aol[i].arr[0].str,dataCheck->str)==0)
    {
      return i;
    }
  }
}

void printValues(fullList * mat, int index)
{
  printf("%d\n", mat->aol[index].arrayListSize);
  for(int i = 1;i <mat->aol[index].arrayListSize;i++)
  {
    printf("%s\n",mat->aol[index].arr[i].str);
  }
}


int main (void)
{
  int input;
  int test;
  char operation;
  char name [101];
  char symptom [101];
  char lookingFor [8];
  char buffer [101];
  scanf("%d",&input);
  fullList * symp = newSympList();
  fullList * student = newSympList();
  for(int i = 0; i < input; i++)
  {
    scanf(" %c",&operation);
    if(operation == 'u')
    {
      scanf("%s %s",name,symptom);
      //scanf("%s",symptom);
      update(student,symp,name,symptom);
    //update(student,symp,"john","sneezed");
    //update(student,symp,"john","coughed");
    //update(student,symp,"tyler","cried");
    }
    else if(operation == 'q')
    {
      scanf("%s %s",lookingFor,buffer);
      //scanf("%s",buffer);
      if(strcmp(lookingFor,"student") == 0)
      {
        test = findRow(student,buffer);
        printValues(student,test);
      }
      else
      {
        test = findRow(symp,buffer);
        printValues(symp,test);
      }
    }
  }
  /*printf("here\n");
  printf("%s\n",student->aol[1].arr[0].str);
  printf("%s\n",student->aol[0].arr[2].str);*/
return 0;
}
