#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TRUE (1==1)
#define FALSE (!TRUE)
#define EPS 1e-4

int search(double * equationValueArray,int low,int high,double value)
{
  int middle;
  while (low <= high)
  {
      middle = low + (high - low)/2;
      if (value < equationValueArray[middle])
          low = middle + 1;
      else if (value > equationValueArray[middle])
          high = middle - 1;
      else
          return middle + 1;
  }
}

void setArray(double * equationValueArray,double hardWareFactor, unsigned long int numberOfStudents)
{
    int index = 0;
    double i = 0;
    double answer;
    equationValueArray = (double * )calloc((numberOfStudents * 1000),sizeof(double));
    for(i = 0; i < numberOfStudents; i+= 0.001)
    {
        answer = ((numberOfStudents)/ (pow(hardWareFactor,sqrt(i))))+i;
        equationValueArray[index]= answer;
      //  printf("%lf %lf\n",i,equationValueArray[index]);
        if(index == 0)
        {
          //so it works
        }
         else if (equationValueArray[index] > equationValueArray[index - 1])
        {
          break;
        }
        index++;
    }
    printf("%lf\n",equationValueArray[search(equationValueArray,0,numberOfStudents * 1000,equationValueArray[index - 1])-1]);
}

double formula(double middle, double numberOfStudents, double hardWareFactor)
{
  //printf("%lf\n", (numberOfStudents)/ (pow(hardWareFactor,sqrt(middle))));
  return ((numberOfStudents)/ (pow(hardWareFactor,sqrt(middle))))+middle;
}

int eq(double lo, double hi)
{
  double diff = fabs(lo - hi);
  if (diff < EPS)
  {
   return TRUE;
  }

  return FALSE;
}


int main (void)
{
    unsigned long int numberOfStudents;
    double hardWareFactor;
    double * equationValueArray;
    int n;
    double answer;
    double lo = 0;
    double hi = 0;
    scanf("%d",&n);
    for(int i = 0; i < n; i++)
    {
    //scanf("%lu %lf",&numberOfStudents,&hardWareFactor);
    //setArray(equationValueArray,hardWareFactor,numberOfStudents); //easier way in my opinion
      scanf("%lu",&numberOfStudents);
      scanf("%lf",&hardWareFactor);
      hi = numberOfStudents;
      while(!eq(lo,hi))
      {
        double m1 = (2 * lo + hi) / 3;
        double m2 = (lo + 2 * hi) / 3;
        if(formula(m1,numberOfStudents,hardWareFactor) > formula(m2,numberOfStudents,hardWareFactor))
        {
          lo = m1;
        }
        else
        {
          hi = m2;
        }
      }
      answer = formula(((lo + hi)/2),numberOfStudents,hardWareFactor);
      printf("%lf\n",answer);
    }


    return 0;
}
