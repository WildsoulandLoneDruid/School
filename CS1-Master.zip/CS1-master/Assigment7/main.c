// Juan Herrea Thanks Joel
#include <stdio.h>
#include <stdlib.h>
// For Simplicity since they are never change
int input;
int * postOrder;
int * preOrder;
int * postIndex;
int * preIndex;

void inOrder(int preLow, int preHigh, int postLow, int postHigh)
{
  // New updates for the bounds of the array
  int newPrelow;
  int newPreHigh;
  int newPostlow;
  int newPostHigh;
  // We need this to find the next root on the next sotrage
  int prePastRoot;
  int postPriorToRoot;
  // Base canse if the Bounds match it means there is onoy one number left so we print that number
  if(preLow == preHigh)
  {
    printf("%d ",preOrder[preLow]);
    return;
  }
  // This is for the single child case where we can only go either one right and or left up to me
  if(postOrder[postHigh - 1] == preOrder[preLow + 1])
  {
    // right postOrderbounds
    newPostlow = postLow;
    newPostHigh = postIndex[postOrder[postHigh - 1] - 1];
    //right preOrderBounds
    newPrelow = preIndex[preOrder[preLow + 1] - 1];
    newPreHigh = preHigh;
    // recursive side for the right bounds since we are going to the right
    inOrder(newPrelow,newPreHigh,newPostlow,newPostHigh);
    printf("%d ",preOrder[preLow]);
    return;
  }
  //Left postOrder Bounds
  // Pre past Root is the value before the ROOT is the Post Root, New post low is the same as the original and Post high is the index of the number found before the root
  prePastRoot = preOrder[preLow + 1];
  newPostlow = postLow;
  newPostHigh = postIndex[prePastRoot - 1];
  //Left preOrder Bounds same as before but instead for Pre bounds, we get the next one aftr the root for low and for high we get the value of the last pre get the index and substract minues 1
  postPriorToRoot = postOrder[postHigh - 1];
  newPrelow = preLow + 1;
  newPreHigh = preIndex[postPriorToRoot - 1] - 1;
  // Left recursive call
  inOrder(newPrelow,newPreHigh,newPostlow,newPostHigh);
  // Print
  printf("%d ",preOrder[preLow]);
  //Right
  // right postOrderbounds very similar to the one above, Powst low gets the one before th Post root and adds one to the index while Post High gets the one previos to the root
  newPostlow = postIndex[prePastRoot - 1] + 1;
  newPostHigh = postHigh - 1;
  //right preOrderBounds We get the Index of the number of Post and the New Pre High is the same as the current high
  newPrelow = preIndex[postPriorToRoot - 1];
  newPreHigh = preHigh;
  inOrder(newPrelow,newPreHigh,newPostlow,newPostHigh);
}

int main ()
{
  int temp;
  scanf("%d",&input);
  postOrder = calloc(input,sizeof(int));
  postIndex = calloc(input,sizeof(int));
  preOrder = calloc(input,sizeof(int));
  preIndex = calloc(input,sizeof(int));
  //Post Order
  for(int i = 0; i < input; i++)
  {
    scanf("%d",&temp);
    postOrder[i] = temp;
    postIndex[temp - 1] = i;
  }
  //Pre Order
  for(int i = 0; i < input; i++)
  {
    scanf("%d",&temp);
    preOrder[i] = temp;
    preIndex[temp - 1] = i;
  }
  // Since we are using index we want to use input - 1 so instead of 6 we use 0-5
  inOrder(0, input - 1, 0, input - 1);
  printf("\n");
}
