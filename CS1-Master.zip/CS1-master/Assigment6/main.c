
// This program tests the three basic functions
// of a stack which is implemented with an array
// list
// All of the functions in the program assume
// that allocation is successful

#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_CAP   1
#define MAX_OPS       30

#define PUSH_CHANCE   60

#define IMPOSSIBLE    -1

#define DEBUG

int flag = 0;
int addedValueOverFlow = 0;

typedef struct ArrayList {
   int * values;
   int size;
   int cap;
} ArrayList;

typedef struct Stack {
   ArrayList * list;
} Stack;

ArrayList * createArrayList();
int get(ArrayList *, int);
void append(ArrayList *, int);
void removeLast(ArrayList *);
void expand(ArrayList *);
void cleanArrayList(ArrayList *);

Stack * createStack();
void push(Stack *, int);
void pop(Stack *);
int top(Stack *);
void cleanStack(Stack *);

// My methods

int getBrakeNumber(Stack * stk)
{
  int brokenChain = 0;
    for(int i = 0; i < stk->list->size; i++)
    {
      if(stk->list->values[i] == -1)
      brokenChain++;
    }

  return brokenChain;
}

int getLowestIndex(Stack * stk)
{
  int lowestIndex;
  for(int i = stk->list->size; i >= 0; i--)
  {
    if(stk->list->values[i] == -1)
    {
      lowestIndex = i;
    }
  }
  return lowestIndex;
}

void popAllValues(Stack * stk)
{
  for(int i = 0; i < stk->list->cap; i++)
  {
    pop(stk);
  }
}

int additionalMath(Stack * stk2)
{
  int brokenLinks;
  int firstBrokenIndex;
  int numberAdded;
  firstBrokenIndex = getLowestIndex(stk2);
  numberAdded = stk2->list->size - firstBrokenIndex;
  if(flag == 1)
  printf("Chain is broken at link %d. New height is %d\n",stk2->list->size + addedValueOverFlow,firstBrokenIndex);
  addedValueOverFlow = addedValueOverFlow + stk2->list->size;
  return numberAdded;
}


int addToChain(Stack * stk, int input)
{
   Stack * stk2 = createStack();
   int brokenLinks;
  int firstBrokenIndex;
  int numberOfChains;
  int numberAdded;
  int temp;
  push(stk,input);
  if(input == -1)
  {
    pop(stk);
  }
  for(int i = 0; i < stk->list->size; i++)
  {
    if(stk->list->size > 1 && input >= 0)
    {
      for(int j = 0; j < stk->list->size - 1; j++)
      {
        temp = stk->list->values[j] - 1;
        stk->list->values[j] = temp;
        printf("Value at index %d: %d\n",j,stk->list->values[j]);
        numberOfChains = j;
      }
      for(int j = 0; j < stk->list->size - 1; j++)
      {
        if(stk->list->values[j] == -1)
        {
          flag = 1;
          printf("Chain Broke!!!!!!!\n");
          stk2 = stk;
          numberAdded = additionalMath(stk2);
          brokenLinks = getBrakeNumber(stk2);
          firstBrokenIndex = getLowestIndex(stk2);
          printf("Ending chain height is %d\n",stk->list->values[0] + numberAdded);
          printf("There are %d broken links and %d  whole links on the floor\n",brokenLinks,numberAdded - brokenLinks);
          popAllValues(stk);
          break;
        }
      }
      break;
    }
  }
  return 0;
}


int main()
{
   int input;
   int brokenLinks;
   int brokenCounter = 0;
  int firstBrokenIndex;
  int numberOfChains;
  int numberAdded;
  int temp;
   Stack * stk = createStack();
   Stack * stk2 = createStack();
   do {
     scanf("%d",&input);
     addToChain(stk,input);
     brokenCounter++;
      printf("--------ITERATION %d---------\n",brokenCounter);
   } while(input >= 0);
   if(flag == 0)
   {
     stk2 = stk;
     numberAdded = additionalMath(stk2);
     brokenLinks = getBrakeNumber(stk2);
     firstBrokenIndex = getLowestIndex(stk2);
     printf("Ending chain height is %d\n",stk2->list->size);
     printf("There are 0 broken links and 0  whole links on the floor\n");
   }

   for(int i = 0; i < stk->list->size; i++)
   {
     printf("Value at index %d: %d\n",i,stk->list->values[i]);
   }


   // Return a zero signifying a successful execution
   return 0;
}


// Function to create the array list
ArrayList * createArrayList()
{
   // Allocate
   ArrayList * ret =
      calloc(1, sizeof(ArrayList));
   ret->values =
      calloc(DEFAULT_CAP, sizeof(int));

   // Initialize
   ret->size = 0;
   ret->cap = DEFAULT_CAP;

   // Return the create array list
   return ret;
}

int get(ArrayList * list, int index)
{
   // Check if the index was invalid
   if (index < 0 || index >= list->size)
      return IMPOSSIBLE;

   // return the value at the selected index
   return list->values[index];
}

void append(ArrayList * list, int value)
{
   // Check if full
   if (list->size == list->cap)
   {
      expand(list);
   }

   // Put the element in the last spot in the array
   list->values[list->size] = value;
   list->size++;
}

void removeLast(ArrayList * list)
{
   // Simply decrement the size of the list
   if (list->size != 0)
      list->size--;
}

void expand(ArrayList * list)
{
   int i;

   // Prepare the new values
   int newCap = list->cap * 2;
   int * newValues = calloc(newCap, sizeof(int));

   // Copy over the values
   for (i = 0; i < list->cap; i++)
      newValues[i] = list->values[i];

   // Remove the old memory
   free(list->values);

   // Update the values
   list->values = newValues;
   list->cap = newCap;
}

void cleanArrayList(ArrayList * list)
{
   // Free the values
   free(list->values);

   // Free the full list
   free(list);
}


Stack * createStack()
{
    // Allocate memory for the stack
    Stack * stk = calloc(1, sizeof(Stack));
    stk->list = createArrayList();
}

void push(Stack * stk, int value)
{
   // Append the value to the array list
   append(stk->list, value);
}

void pop(Stack * stk)
{
   // Remove the last value from the array list
   removeLast(stk->list);
}

int top(Stack * stk)
{
   // Return the last element in the array list
   return get(stk->list, stk->list->size - 1);
}

void cleanStack(Stack * stk)
{
   // Free the array list
   cleanArrayList(stk->list);

   // Free the stack memory
   free(stk);
}
