// This program tests the three basic functions
// of a stack which is implemented with an array
// list
// All of the functions in the program assume
// that allocation is successful

#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_CAP   1
#define MAX_OPS       30

#define PUSH_CHANCE   60

#define IMPOSSIBLE    -1

#define DEBUG

int flag = 0;
int flag2 = 0;
int brokenLinks = 0;
int addedValueOverFlow = 0;
int firstBrokenIndex = 0;
int numberAdded;
int workAround =0 ;

typedef struct ArrayList {
   int * values;
   int size;
   int cap;
} ArrayList;

typedef struct Stack {
   ArrayList * list;
} Stack;

ArrayList * createArrayList();
int get(ArrayList *, int);
void append(ArrayList *, int);
void removeLast(ArrayList *);
void expand(ArrayList *);
void cleanArrayList(ArrayList *);

Stack * createStack();
void push(Stack *, int);
void pop(Stack *);
int top(Stack *);
void cleanStack(Stack *);

// My methods

int getBrakeNumber(Stack * stk)
{
  // We determine the amount of borken chains once a brake does happen
  int brokenChain = 0;
    for(int i = 0; i < stk->list->size; i++)
    {
      if(stk->list->values[i] == -1)
      brokenChain++;
    }
  return brokenChain;
}

int getLowestIndex(Stack * stk)
{
  // In the case of multiple chain brakes we want to determine the one with higher priority
  // aka the one closest to the start of the chain
  int lowestIndex;
  for(int i = stk->list->size; i >= 0; i--)
  {
    if(stk->list->values[i] == -1)
    {
      lowestIndex = i;
    }
  }
  return lowestIndex;
}

void popAllValues(Stack * stk,int sizetoPop)
{
  // Pop all values below a broken chain also adds the strnght of the chains above
  // the one that snapped back
  for(int i = 0; i < sizetoPop; i++)
  {
    pop(stk);
  }
  for(int i = 0; i < stk->list->size; i++)
  {
    stk->list->values[i] = stk->list->values[i] + sizetoPop;
  }
}

int additionalMath(Stack * stk2)
{
  // We do mathematics here, first we need to calculate the first chain that brakes and then we caculate where the chain broke the first time,
  // and the new height after the chain brakes
  int firstBrokenIndex;
  firstBrokenIndex = getLowestIndex(stk2);
  numberAdded = stk2->list->size - firstBrokenIndex;
  if(flag == 1)
  printf("Chain is broken at link %d. New height is %d\n",stk2->list->size + addedValueOverFlow,firstBrokenIndex);
  addedValueOverFlow = addedValueOverFlow + stk2->list->size;
  return numberAdded;
}


int addToChain(Stack * stk, int input)
{
   Stack * stk2 = createStack();
  int temp;
  int sizetoPop;
  push(stk,input);
  if(input == -1)
  {
    // Pop all values that are meant to end the while loop
    pop(stk);
  }
    if(stk->list->size > 1 && input >= 0)
    {
      for(int j = 0; j < stk->list->size - 1; j++)
      {
        // Everytime we add a value we need to sub one from the the pior ones
        temp = stk->list->values[j] - 1;
        stk->list->values[j] = temp;
      }
      for(int j = 0; j < stk->list->size - 1; j++)
      {
        if(stk->list->values[j] == -1)
        {
          // Flags are used to indicate to other programs that a chian brake happened
          flag = 1;
          flag2 = 1;
          // temp stack because is better to manipulate that one that the other orginal one
          stk2 = stk;
          // Math calculations to get the information that we need, methods explained earlier
          numberAdded = additionalMath(stk2);
          brokenLinks = brokenLinks + getBrakeNumber(stk2);
          firstBrokenIndex = firstBrokenIndex +  getLowestIndex(stk2);
          // We need to calculate how many numbers to top
          sizetoPop = stk->list->size - firstBrokenIndex;
          popAllValues(stk,sizetoPop);
          // We need to store the size for later use to get te height
          workAround = stk->list->size ;
          break;
        }
      }
    }
  return 0;
}


int main()
{
   int input=0;
   int counter;
   // Creates an Instance of Stack
   Stack * stk = createStack();
   while(input >= 0)
   {
     // flag is used to determine if the chain was broken if it was we want to restard the counter
     flag = 0;
     scanf("%d",&input);
     addToChain(stk,input);
     if(flag == 0)
     {
       counter++;
     }
     else
     {
       counter = 0;
     }
   }
   if(flag2 == 0)
   {
     // This case happens when the chain was not broken
     printf("Ending chain height is %d\n",stk->list->size);
     printf("There are 0 broken links and 0  whole links on the floor\n");
   }
   else
   {
     // This case happens when the chain is broken at one point
      printf("Ending chain height is %d\n",workAround + counter - 1);
      // Over flow - firstindex and the links borken gives us the total amunt of links in the floor
      printf("There are %d broken links and %d  whole links on the floor\n",brokenLinks,
        (addedValueOverFlow) - firstBrokenIndex - brokenLinks);
   }

   // Return a zero signifying a successful execution
   cleanStack(stk);
   return 0;
}


// Function to create the array list
ArrayList * createArrayList()
{
   // Allocate
   ArrayList * ret =
      calloc(1, sizeof(ArrayList));
   ret->values =
      calloc(DEFAULT_CAP, sizeof(int));

   // Initialize
   ret->size = 0;
   ret->cap = DEFAULT_CAP;

   // Return the create array list
   return ret;
}

int get(ArrayList * list, int index)
{
   // Check if the index was invalid
   if (index < 0 || index >= list->size)
      return IMPOSSIBLE;

   // return the value at the selected index
   return list->values[index];
}

void append(ArrayList * list, int value)
{
   // Check if full
   if (list->size == list->cap)
   {
      expand(list);
   }

   // Put the element in the last spot in the array
   list->values[list->size] = value;
   list->size++;
}

void removeLast(ArrayList * list)
{
   // Simply decrement the size of the list
   if (list->size != 0)
      list->size--;
}

void expand(ArrayList * list)
{
   int i;

   // Prepare the new values
   int newCap = list->cap * 2;
   int * newValues = calloc(newCap, sizeof(int));

   // Copy over the values
   for (i = 0; i < list->cap; i++)
      newValues[i] = list->values[i];

   // Remove the old memory
   free(list->values);

   // Update the values
   list->values = newValues;
   list->cap = newCap;
}

void cleanArrayList(ArrayList * list)
{
   // Free the values
   free(list->values);

   // Free the full list
   free(list);
}


Stack * createStack()
{
    // Allocate memory for the stack
    Stack * stk = calloc(1, sizeof(Stack));
    stk->list = createArrayList();
    return stk;
}

void push(Stack * stk, int value)
{
   // Append the value to the array list
   append(stk->list, value);
}

void pop(Stack * stk)
{
   // Remove the last value from the array list
   removeLast(stk->list);
}

int top(Stack * stk)
{
   // Return the last element in the array list
   return get(stk->list, stk->list->size - 1);
}

void cleanStack(Stack * stk)
{
   // Free the array list
   cleanArrayList(stk->list);

   // Free the stack memory
   free(stk);
}
