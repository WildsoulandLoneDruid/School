#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


int main (void)
{
  char sentence [1000] = "UCF, its athletic program, and the university's alumni and sports fans are sometimes jointly referred to as the UCF Nation, and are represented by the mascot Knightro. The Knight was chosen as the university mascot in 1970 by student election. The Knights of Pegasus was a submission put forth by students, staff, and faculty, who wished to replace UCF's original mascot, theCitronaut, which was a mix between an orange and an astronaut. The Knights were also chosen over Vincent the Vulture, which was a popular unofficial mascot among students at the time. In 1994, Knightro debuted as the Knights official athletic mascot.";
  char word1 [100];

  scanf("%s\n",word1);
  char * start = NULL;
  int counter  = 0;
  int finalCounter = 0;
  int i = 0;
  int j = 0;
  do
  {
    i++;
    j++;
    if(sentence[i] == word1[i] && word1[i] != NULL)
    {
      counter++;
    }
    else
    {
      counter = 0;
      j = 0;
    }
    if(counter == strlen(word1))
    {
      finalCounter++;
    }

  } while(sentence[i] != NULL);

  printf("%s : "word1);
  for(int k = 0; j < finalCounter; j++)
  {
    printf("#");
  }
  printf("\n");
  return 0;
}
