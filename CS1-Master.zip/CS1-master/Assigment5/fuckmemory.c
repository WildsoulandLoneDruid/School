#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STRING_LENGTH 100
#define ALPHA_LENGHT 26

char **inputNames;
char alphabetOrder [ALPHA_LENGHT];
int numOrder[ALPHA_LENGHT];


int myStr(char array1[], char array2[],int numberOfNames)
{
  // Value of the character for
  int indexC1;
  int indexC2;

  for(int j = 0; j < ALPHA_LENGHT;j++)
  {
      // Assigned number of the letter with the correspoding letter
      indexC1 = numOrder[array1[j] - 97];
      indexC2 = numOrder[array2[j] - 97];
    if(indexC1 == indexC2)
    {
      // We need this for words that are similar
      continue;
    }
    else
    {
      // Returns the value to determine which words comes before the others
        return indexC1 - indexC2;
    }
  }
}

void merge(int low,int high, int numberOfNames)
{
  int mid = (low + high) / 2;
  int frontPtr = low;
  int backPtr = mid + 1;
  int mergePtr = 0;
  // Dynamic allocation of the copy of Input Names
  char **copyofInputNames = (char**)calloc(high - low + 1, sizeof(char*));
  for(int i = 0; i < (high - low + 1);i++)
  {
    copyofInputNames[i] = (char*)calloc(100 + 1,sizeof(char));
  }

  if ( low == high)
  {
    return;
  }

  merge(low, mid,numberOfNames);
  merge(mid + 1, high,numberOfNames);

  while(mergePtr <= high - low)
  {
    //Calles the comparison function and depeding on that we sort the name respectively
    if(frontPtr == mid + 1 || (backPtr != high + 1 && myStr(inputNames[frontPtr],inputNames[backPtr],numberOfNames) > 0))
    {
      strcpy(copyofInputNames[mergePtr++],inputNames[backPtr++]);
    }
    else
    {
      strcpy(copyofInputNames[mergePtr++],inputNames[frontPtr++]);
    }
  }
  // Copying the values of the sorted copyofInputNames to inputNames
  for (int i = low; i <= high; i++)
  {
    strcpy(inputNames[i],copyofInputNames[i - low]);
  }
}

int main(void)
{
  char singleName[MAX_STRING_LENGTH];
  char singleLetter;
  int numberOfNames;

  // Creates the array holding the 26 letters for the new ALPHABET
  for (int i = 0; i < 26; i = i + 1)
  {
    scanf("%c \n",&singleLetter);
    alphabetOrder[i] = singleLetter;
  }
  // We are finding the first instance of a-b-c-d-e ....., when we do
  // we then get the numOrder array and for idex 0-1-2-3-4 we will add
  // the poisiton of the letter in the int array
  for(int i = 0; i < ALPHA_LENGHT; i++)
  {
    for(int j = 0; j < ALPHA_LENGHT; j++)
    {
      if((alphabetOrder[j] - 'a') == i)
      {
        numOrder[i] = j;
        break;
      }
    }
  }
  scanf("%d",&numberOfNames);
  // Dynamic allocation of InputNames
  inputNames = (char**)calloc(numberOfNames,sizeof(char*));
  for(int i = 0; i < numberOfNames; i++)
  {
    inputNames[i] = (char*) calloc(100 + 1,sizeof(char));
  }
  // Assigning the names into the 2-d array
  for(int i = 0; i < numberOfNames; i++)
  {
    scanf("%s",singleName);
    for(int j = 0;j < MAX_STRING_LENGTH; j++)
    {
      inputNames[i][j] = singleName[j];
    }
  }
  // Number of names - 1 allows us to print all names
  // instead of names - 1
  merge(0,numberOfNames - 1,numberOfNames);
  // Prints the sorted array
  for(int i = 0; i < numberOfNames;i++)
  {
    printf("%s\n",inputNames[i]);
  }

  free(inputNames);

  return 0;
}
