#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define FALSE   0
#define TRUE    1
#define MAX_STRING_LENGTH 100
#define ALPHA_LENGHT 26

char **inputNames;
//char (*copyofInputNames)[MAX_STRING_LENGTH];
char alphabetOrder [ALPHA_LENGHT];
int numOrder[ALPHA_LENGHT];

int myStr (char array1[], char array2[], char alphabetOrder[],int numberOfNames)
{
  int numberAlphabet [26];
  // for(int i = 0; i < numberOfNames;i++)
  // {
  //   printf(" Array 1 Word: %s \n Array 2 Word %s \n Strcmp = %d\n",array1[i],array2[i],strcmp(array1[i],array2[i]));
  // }
  // printf("---------mySTR----------\n");
  int indexC1;
  int indexC2;


  char str1[MAX_STRING_LENGTH];
  char str2[MAX_STRING_LENGTH];

  for(int j = 0; j < ALPHA_LENGHT;j++)
  {
      //Get letter of the array1
      indexC1 = numOrder[array1[j] - 97];
      indexC2 = numOrder[array2[j] - 97];
    if(indexC1 == indexC2)
    {
      continue;
    }
    else
    {
        return indexC1 - indexC2;
    }
  }

    // for(int j = 0; j < strlen(array1);j++)
    // {
    //   for(int k = 0; k < ALPHA_LENGHT;k++)
    //   {
    //     if(array1[j] == alphabetOrder[k])
    //     {
    //       indexC1 = k + 1;
    //       break;
    //     }
    //   }
    //   //-------------------------------
    //   for(int k = 0; k < ALPHA_LENGHT;k++)
    //   {
    //     if(array2[j] == alphabetOrder[k])
    //     {
    //       indexC2 = k + 1;
    //       break;
    //     }
    //   }
    //   return indexC1 - indexC2;
    // }

}

void merge(int low,int high, int numberOfNames)
{
  char copyofInputNames [numberOfNames][MAX_STRING_LENGTH];
  int mid = (low + high) / 2;
  int frontPtr = low;
  int backPtr = mid + 1;
  int mergePtr = 0;
  if ( low == high)
  {
    return;
  }
  merge(low, mid,numberOfNames);
  merge(mid + 1, high,numberOfNames);

  while(mergePtr <= high - low)
  {
    if(frontPtr == mid + 1 || backPtr != high + 1 && myStr(inputNames[frontPtr],inputNames[backPtr],alphabetOrder,numberOfNames) >= 0)
    {
      strcpy(copyofInputNames[mergePtr++],inputNames[backPtr++]);
    }
    else
    {
      strcpy(copyofInputNames[mergePtr++],inputNames[frontPtr++]);
    }
  }
  for (int i = low; i <= high; i++)
  {
    strcpy(inputNames[i],copyofInputNames[i - low]);
  }
}

int main(void)
{
  char singleName[MAX_STRING_LENGTH];
  char singleLetter;
  int numberOfNames;
  // Creates the array holding the 26 letters for the new ALPHABET
  for (int i = 0; i < 26; i = i + 1)
  {
    scanf("%c \n",&singleLetter);
    alphabetOrder[i] = singleLetter;
  }
  for(int i = 0; i < ALPHA_LENGHT; i++)
  {
    for(int j = 0; j < ALPHA_LENGHT; j++)
    {
      if((alphabetOrder[j] - 'a') == i)
      {
        numOrder[i] = j;
        break;
      }
    }
  }

  scanf("%d",&numberOfNames);
  //Creating Memory
  //inputNames = calloc(numberOfNames,sizeof(*inputNames));
  inputNames = (char**)calloc(numberOfNames,sizeof(char*));
  for(int i = 0; i < numberOfNames; i++)
  {
    inputNames[i] = (char*) calloc(100 + 1,sizeof(char));
  }
  //copyofInputNames = calloc(numberOfNames,sizeof(*copyofInputNames));
  for(int i = 0; i < numberOfNames; i++)
  {
    scanf("%s",singleName);
    for(int j = 0;j < MAX_STRING_LENGTH; j++)
    {
      inputNames[i][j] = singleName[j];
    }
  }
  merge(0,numberOfNames - 1,numberOfNames);
  printf("After Sort \n");
  for( int i = 0; i < numberOfNames;i++)
  {
    printf("%s\n",inputNames[i]);
  }

  free(inputNames);


  return 0;
}
