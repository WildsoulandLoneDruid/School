#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#define FALSE 0
#define TRUE 1
#define MAX_STRING_LENGTH 13
#define ALPHABET 26

// Global Variables for ease of acess and I did not want to pass a parameter to permute to simply pass
// to badWordCounterThis values would have been also pass by reference so this was simpler
int permutationNumber;
int badWords = 0;
int numofBadWords = 0;
// Ghetto way of a dynamic 2D
char( * badWordsX)[MAX_STRING_LENGTH];

void badWordCounter(char * setLetters)
{
  char * temp;
  for (int i = 0; i < numofBadWords; i++)
  {
    temp = strstr(setLetters, badWordsX[i]);
    // strstr returns null if word is not found
    if (temp != NULL) {
      badWords++;
      // printf("bad words %d\n",badWords);
      // this is when in case of SAME both ME and SAM are both words but we want to count it as 1
      break;
    }
  }
}
// The recursive method that does the permuation
void permute(int * usedLetters, char * setLetters, char * inputString, int passwordLength, int emptySpot)
{
  int i;
  int duplicatedWords[ALPHABET];
  if (passwordLength == emptySpot)
  { //no more empty spots! entire possible password filled in
    permutationNumber++;
    //printf("%d. ", ++permutationNumber);// Print and update the permutationNumber
    //for (i = 0; i < passwordLength; i++) // Print the string
    //printf("%c", setLetters[i]);
    //printf("\n");
    // Of to count how many words we get, we simply pass in the permuted word we just created
    // and chyeck to see if it in indeed a bad work if it is then we add one to badword counter
    badWordCounter(setLetters);
    return; // No recursion for base case!
  }
  for (int i = 0; i < ALPHABET; i++) {
    duplicatedWords[i] = 0;
  }
  for (i = 0; i < passwordLength; i++)
  { // try placing every unused letter in this spot
    if (usedLetters[i] == FALSE && duplicatedWords[inputString[i] - 'a'] == 0)
    {
      usedLetters[i] = TRUE; // Set the value to used
      // If a letter lets say A was already used then we can simply skip it again so in the array[0] = 1 then skip it if we can skip it
      duplicatedWords[inputString[i] - 'a'] = 1;
      //duplicatedWords[setLetters[i] -'a'] = TRUE;
      setLetters[emptySpot] = (inputString)[i]; // Assign the value
      permute(usedLetters, setLetters, inputString, passwordLength, emptySpot + 1); // Recurse
      // Undo the changes
      usedLetters[i] = FALSE;
      setLetters[emptySpot] = '\0';
    }
  }
  return;
}

int main(void) 
{
  int * usedLetters; // Which letters have been used
  char * setLetters; // The current arrangement of letters
  int i;
  char inputString[MAX_STRING_LENGTH];
  char badWordInput[MAX_STRING_LENGTH];
  permutationNumber = 0; // we've seen no permutations yet
  scanf("%s", inputString);
  scanf("%d", & numofBadWords);

  // Create memory
  usedLetters = (int * ) calloc(strlen(inputString), sizeof(int));
  setLetters = (char * ) calloc(strlen(inputString), sizeof(char));
  //badWordsY = (char **) calloc(numofBadWords, sizeof(char *));
  badWordsX = calloc(numofBadWords, sizeof( * badWordsX));

  for (int numBad = 0; numBad < numofBadWords; numBad++) {
    scanf("%s", badWordInput);
    for (int j = 0; j < MAX_STRING_LENGTH; j++) {
      badWordsX[numBad][j] = badWordInput[j];
    }
  }
  // Fill the arrays
  for (i = 0; i < strlen(inputString); i++) {
    usedLetters[i] = FALSE; //no letters have been used yet
    setLetters[i] = '\0'; //no letters have been set yet
  }

  //we'll set one letter at a time, move on to next with remaining options, fill in entire password, then backtrace
  permute(usedLetters, setLetters, inputString, strlen(inputString), 0); // Run the recursive method
  printf("%d\n", permutationNumber - badWords);
  free(badWordsX);
  free(usedLetters);
  free(setLetters);

  return 0;
}
