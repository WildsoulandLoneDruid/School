#ifndef ENGINE_H_INCLUDED
#define ENGINE_H_INCLUDED
#include <iostream>
using namespace std;

class Movement {
	private:
		double r,d;
	public: 
		Movement(double lengthOfCourse,double accelerationOfObj){
			r=accelerationOfObj;
			d=lengthOfCourse;
		}
		double getPositionAt(double x){
			return r*x;
		}
		double getTimeAt(double x){
			return x/r;
		}
		double getAccel(){
			return r;
		}
		void setAccel(double acc){
			r=acc;
		}

	
	
};
#endif // ENGINE_H_INCLUDED
