#ifndef Simulation_H_INCLUDED
#define Simulation_H_INCLUDE
#include <iostream>
using namespace std;

class Simluation{
	
	//Class will take all Vehicle.h and Type.h and use them to run the sumlation depending on lenght of the track and speed/maxacc/ and gas tank of car. 
	
	
	
	
};




#endif // Simulation_H_INCLUDED
