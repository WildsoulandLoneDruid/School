#ifndef ENGINE_H_INCLUDED
#define ENGINE_H_INCLUDED
#include <iostream>
using namespace std;

class Engine {
	double maxAcc;
	int cylinders;
	public: 
	Engine (double mAcc,double cylinder){
		maxAcc= mAcc;
		cylinders= cylinder;
	}	 
	
	void set_Maxacc(double acc){
	 maxAcc=acc;	
	}
	
	void set_Maxspeed(double cyl){
	 cylinders=cyl;	
	}
	double getMaxAcceleration(){
		return maxAcc;
	}
	double getCylinders(){
		return cylinders;
	}
	
};
#endif // ENGINE_H_INCLUDED
