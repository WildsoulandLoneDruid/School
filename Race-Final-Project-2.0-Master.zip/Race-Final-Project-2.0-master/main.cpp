#include <iostream>
#include <string>
#include "Vehicle.h"
#include "Engine.h"
#include "TireType.h"
#include "Type.h"
#include <iomanip>

using namespace std;
void menuOfCar(Type * car);
void buildofCar(Type * cars);
void menu();
bool confirm(bool);
int main(){
	Type * type1 = new Type();
	Type * type2 = new Type();
	Type * type3 = new Type();
	Type * type4 = new Type();
	double time;

 	
 	cout<<"===This is a program simulation a race between 4 cars=== \n \n";
 	bool q =true;
 		while(q == true){
		int carBuild;
		 cout<<"What car would you like to build? or press 5 to continue \n";
 		 cin>>carBuild;
 		 	switch (carBuild){
 		 		case 1:{
 					buildofCar(type1);
 					break;
				}
				 
				case 2:{
					buildofCar(type2);
					break;		
				}
				
				case 3:{
					buildofCar(type3);
					break;
				}
				
				case 4:{
					buildofCar(type4);
					break;
				}
				
				case 5:{
					q = confirm(false);
					break;
				}
				default:{
 					cout<<"There are only 4 cars, numbered from 1-4 \n";
					break;
			 	}
 		 		
 		   }
 		 	  q=q?confirm(true):false;
	  }
	  
	  
	  
	bool flag=true;
 	while(flag){
 		int carAsn;
	cout<<"What car would you like to see or enter 5 to continue? \n";
     	cin>>carAsn;
     	
     		switch (carAsn){
 				case 1:{
 					menuOfCar(type1);
 					break;
				 }
				 
				case 2:{
					menuOfCar(type2);
					break;		
				}
				
				case 3:{
					menuOfCar(type3);
					break;
				}
				
				case 4:{
					menuOfCar(type4);
					break;
				}
				
				case 5:{
					flag = confirm(false);	
					break;
				}
				default:{
 					cout<<"There are only 4 cars, numbered from 1-4 \n";
					break;
			 	}
			 }
			  flag=flag?confirm(true):false;
	 } 
	 
	 cout<<"Now to determine a winnier in a table displaying every mile for 10 miles\n";
	 cout<<"Car\t\tDistance\t\tTime \n";
	 for (int i=1;i<=10;i+=2){
	 	cout<<type1->getcarname()<<"\t\t"<<i<<"\t\t\t"<<setprecision(4)<<type1->timeTook(i)<<endl;
	 	cout<<type2->getcarname()<<"\t\t"<<i<<"\t\t\t"<<setprecision(4)<<type2->timeTook(i)<<endl;
	 	cout<<type3->getcarname()<<"\t\t"<<i<<"\t\t\t"<<setprecision(4)<<type3->timeTook(i)<<endl;
	 	cout<<type4->getcarname()<<"\t\t"<<i<<"\t\t\t"<<setprecision(4)<<type4->timeTook(i)<<endl;
	}
	string name[4];
	name[0]=type1->getcarname();
	name[1]=type2->getcarname();
	name[2]=type3->getcarname();
	name[3]=type4->getcarname();
	
	double timetook[4];
	timetook[0]=type1->timeTook(10);
	timetook[1]=type2->timeTook(10);
	timetook[2]=type3->timeTook(10);
	timetook[3]=type4->timeTook(10);
	
	double cur=timetook[0];
	int index = 0;
	
	for (int c=1;c<4;c++){
		if(timetook[c]<cur){
			cur=timetook[c];
			index = c;
		}
	}
     cout<<"The Winner is \n";	
	 cout<<name[index];
}
    
bool confirm(bool menuOrNah){
	cout<<"\nPress the Enter key to continue.\n";
	cin.ignore();
	cin.get();
	
	return menuOrNah;
}

void buildofCar(Type * car){
	car->carBuild();
}


void menuOfCar(Type * car){
	double time;
	int genAsn;
	
	cout<<"Would you like to see: \n"<<"1) General Information \n"<<"2) Time Specific Information \n";
	
	cin>>genAsn;
	
	switch(genAsn){
		case 1:{
			car->display();
			break;
		 }
		case 2:{
			cout<<"At what time? \n";
			cin>>time;
			car->displayInfoAt(time);
			break;
		}
		default:{
			cout<<"That is not one of the options \n";
			break;
		}
		
	 }
}

