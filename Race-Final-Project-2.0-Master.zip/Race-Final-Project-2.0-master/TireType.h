#ifndef TIRETYPE_H_INCLUDED
#define TIRETYPE_H_INCLUDED
#include <iostream>
using namespace std;
class TireType {
	double stickyness,wearAndTear;
	public: 
	TireType(double sticky,double wear){
		stickyness=sticky;
		wearAndTear=wear;
	}
	
	
	void set_Stickyness(double sticky){
		stickyness=sticky;	
	}
	
	void set_Wear(double wear){
	  	wearAndTear=wear;	
	}
	
	double getStickyness(){
		return stickyness;
	}
	double getWear(){
		return wearAndTear;
	}
	
};

#endif // TIRETYPE_H_INCLUDED
