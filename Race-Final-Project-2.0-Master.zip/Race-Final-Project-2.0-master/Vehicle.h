#ifndef VEHICLE_H_INCLUDED
#define VEHICLE_H_INCLUDED
#include <iostream>
#include <cmath>
#include <string>
#include "Engine.h"
#include "TireType.h"


using namespace std;

class Vehicle  {
	private:
		string Color;
		double MaxSpeed;
		double gasTank;
		


	public:
	
		Engine* enginePtr;
		TireType* tirePtr;

	Vehicle(){
		Color = " ";
		MaxSpeed = 0.0;
		gasTank = 0.0;
		enginePtr= new Engine(0,0);
			tirePtr= new TireType(0,0);
	}
	
	Vehicle(string Colors){
		Color = Colors;
	}
	
	Vehicle (double Speed, double gastank){
			MaxSpeed = Speed;
			gasTank = gastank;
	}
	
	Vehicle (string Colors, double Speed, double gastank){
				MaxSpeed = Speed;
				gasTank = gastank;
				Color = Colors;
		}
	
	
	void set_Color(string Colors){
		Color = Colors;
	}
		
	void set_Maxspeed(double Speed){
	 MaxSpeed=Speed;	
	}
	void set_engine(Engine* e){
		enginePtr=e;
	}
	void set_tire(TireType* t){
		tirePtr=t;
	}
	
	void set_gasTank(double gastank){
	 gasTank=gastank;
	 	
	}
	   
  Engine* getengine(){ 
    return   enginePtr; 
    } 
  TireType* getTiretype(){ 
    return tirePtr; 
  } 
	
	string getColor(){
	return Color;
	}
	
	double get_MaxSpeed(){
	return MaxSpeed;
	}
	
	double get_gasTank(){
	return gasTank;
	}
	
	

	double getAccAt(double t){
			double ma=enginePtr->getMaxAcceleration();
			double ms=MaxSpeed;
			double acc= 2*(pow(ma,2)/ms)*t;
			return t > ms ? 0.0 : acc;
	}

	double getSpeedAt(double t){
			double ma=enginePtr->getMaxAcceleration();
			double ms=MaxSpeed;
			double acc= (pow(ma,2)/ms)*pow(t,2);
			return t > ms ? ms : acc;
	}
	double timeTook(double d){
			double ma=enginePtr->getMaxAcceleration();
			double ms=MaxSpeed;
			double first=(pow(ma,5)/(3*pow(ms,4)));
			return d<first?(pow(ma,2)/(3*ms))*pow(d,3):(d-first)/ms+(ms/ma);
		}
	double distanceAt(double t){
		double ma=enginePtr->getMaxAcceleration();
		double ms=MaxSpeed;
		double first=pow(ma,5)/(3*pow(ms,4));
		return t<ma/ms?first:first+(t-(ma/ms))*ms;
	}
	
	double getGasUsed(double t){
		double x= enginePtr->getMaxAcceleration()/MaxSpeed;
		double s= tirePtr->getStickyness();
		double w= tirePtr->getWear();
		return 2*(pow(6,x)/pow(5,x))*t*s-((w/10)*t);
	}
	double getRateOfConsumption(double t){
		double x= enginePtr->getMaxAcceleration()/MaxSpeed;
		double s= tirePtr->getStickyness();
		double w= tirePtr->getWear();
		return 4*pow(1.2,x)*t*s-((w/20)*pow(t,2));
	}
	
	Print(){

   //Code	
}
};




#endif // VEHICLE_H_INCLUDED
