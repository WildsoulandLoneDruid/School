#ifndef TYPE_H_INCLUDED
#define TYPE_H_INCLUDED
#include <iostream>
using namespace std;

class Type : public Vehicle{
	int doors;
	int seats;
	string carname;
public:
	Type(){
		doors = 0;
		seats = 0;
		carname = " ";
	

}
	Type(double door, double seat ){
		doors = door;
		seats = seat;

	}

	Type (Engine* x, TireType* y){
		enginePtr = x;
		tirePtr = y;
	}

	Type(double door, double seat, string carnames){
			doors = door;
			seats = seat;
			carname = carname;
}

	void set_doors(double door){
	 doors=door;	
	}

	void set_carname(string carnames){
	 carname=carnames;	
	}
	
	void set_seats(double seat){
	 seats=seat;	
	}
	double getdoors(){
		return doors;
	}
	double getseats(){
		return seats;
	}

	string getcarname(){
		return carname;
	}

	void display(){
		cout<<"The car name is: "<<carname<<endl;
		cout<<"-Engine- \n"<<"Max Accelleration is: "<<enginePtr->getMaxAcceleration()<<endl<<" Cylinders: "<<enginePtr->getCylinders()<<endl;
		cout<<"-TireType- \n"<<"Tires wear is: "<<tirePtr->getWear()<<endl<<" Sticky factor (Friction): "<<tirePtr->getStickyness()<<endl;
		cout<<"Color: "<<getColor()<<endl;
		cout<<"Max Speed: "<<get_MaxSpeed()<<endl;
		cout<<"Gas Tank Capacity: "<<get_gasTank()<<endl;
		cout<<"Time it took to finish 10 miles: "<<timeTook(10)<<endl;
		cout<<"-Gas- \n";
		cout<<"Amount of Gas used in 10 miles: "<<getGasUsed(10)<<endl;
		cout<<"Initital Tank Capacity: "<<get_gasTank()<<" - "<<getGasUsed(timeTook(10))<<" = "<<get_gasTank()-getGasUsed(timeTook(10))<<endl;
		if(get_gasTank()-getGasUsed(timeTook(10))<=0){
		cout<<"Vehicle ran out of gas \n";
		}
		else{
		cout<<"Vehicle finished the race \n";
		}
		
	}
	
	void displayInfoAt(double t){
		cout<<"The car name is: "<<carname<<endl;
		cout<<"The Car speed at "<<t<<" is "<<getSpeedAt(t)<<endl;
		cout<<"The Car Acceleration at "<<t<<" is "<<getAccAt(t)<<endl;
		cout<<"The Car Distance from start at "<<t<<" is "<<distanceAt(t)<<endl;
		cout<<"The rate of gas comsuption at "<<t<<" is "<<getRateOfConsumption(t)<<endl;
	}
	
	void carBuild(){
		string carn,color;
		double maxac,wear,sticky,maxsp,gasp;
		int cyl,dor,set;
		cout<<"What is the car name: \n";
		cin>>carn;
		cout<<"Doors \n";
		cin>>dor;
		cout<<"Seats \n";
		cin>>set;
		cout<<"-Engine- \n"<<"What is the Max Acceleleration: \n";
		cin>>maxac;
		cout<<"How many cylynders \n";
		cin>>cyl;
		cout<<"-TireType- \n"<<"Tires wear [0-1]: \n";
		cin>>wear;
		cout<<"Sticky Factor [0-1]: \n";
		cin>>sticky;
		cout<<"Car Color: \n";
		cin>>color;
		cout<<"Max Speed: \n";
		cin>>maxsp;
		cout<<"Gas capasity \n";
		cin>>gasp;
		
		this->set_carname(carn);
 		this->set_doors(dor);
 		this->set_seats(set);
 		this->set_Color(color);
 		this->set_Maxspeed(maxsp);
 		this->set_gasTank(gasp);
 		this->set_engine(new Engine(maxac, cyl));
 		this->set_tire(new TireType(sticky,wear));
 
		
			}


};


#endif // TYPE_H_INCLUDED
